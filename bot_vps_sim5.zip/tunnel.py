#!/usr/bin/env python3
# Tunnel public gratuit vers le serveur local (port 8800). Écrit l'URL dans data/public_url.txt.
#   TUNNEL=cloudflared (défaut si le binaire existe) ou TUNNEL=pinggy
import os, re, sys, time, shutil, subprocess, socket, ssl, threading, select
HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.environ.get('SIM_DATA', os.path.join(HERE, 'data')); os.makedirs(DATA, exist_ok=True)
PORT = int(os.environ.get('SIM_PORT', '8800'))
URLF = os.path.join(DATA, 'public_url.txt')
def put(u):
    cur = open(URLF).read().strip() if os.path.exists(URLF) else ''
    if u != cur:
        open(URLF, 'w').write(u + '\n'); print('URL', u, flush=True)
mode = os.environ.get('TUNNEL') or ('cloudflared' if shutil.which('cloudflared') else 'pinggy')
def healthy(u):
    import urllib.request
    try:
        with urllib.request.urlopen(urllib.request.Request(u + '/health', headers={'User-Agent': 'Mozilla/5.0'}), timeout=10) as f: return f.status == 200
    except Exception: return False
if mode == 'cloudflared':
    pr = subprocess.Popen(['cloudflared', 'tunnel', '--no-autoupdate', '--protocol', 'http2', '--url', f'http://localhost:{PORT}'], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    url = [None]
    def rd():
        for line in pr.stdout:
            m = re.search(r'https://[a-z0-9-]+\.trycloudflare\.com', line)
            if m and not url[0]: url[0] = m.group(0)
    threading.Thread(target=rd, daemon=True).start()
    ok = False; t0 = time.time()
    while time.time() - t0 < 90 and pr.poll() is None:
        if url[0] and healthy(url[0]): ok = True; break
        time.sleep(5)
    if ok:
        put(url[0])
        while pr.poll() is None: time.sleep(5)
        sys.exit(pr.returncode or 0)
    print('cloudflared KO -> repli sur pinggy', flush=True)
    try: pr.kill()
    except Exception: pass
# ---- pinggy (SSH sur TLS 443, sans compte ; l'URL change à chaque reconnexion, ~60 min en gratuit)
import paramiko
def pipe(ch):
    try: s = socket.create_connection(('127.0.0.1', PORT), timeout=10)
    except Exception: ch.close(); return
    try:
        while True:
            r, _, _ = select.select([s, ch], [], [], 60)
            if not r: break
            if s in r:
                d = s.recv(32768)
                if not d:
                    try: ch.shutdown_write()
                    except Exception: pass
                    time.sleep(0.25); break
                ch.sendall(d)
            if ch in r:
                d = ch.recv(32768)
                if not d: break
                s.sendall(d)
    except Exception: pass
    finally:
        for x in (s, ch):
            try: x.close()
            except Exception: pass
ctx = ssl.create_default_context(); ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
addr = socket.getaddrinfo('a.pinggy.io', 443, socket.AF_INET, socket.SOCK_STREAM)[0][4]
raw = socket.socket(socket.AF_INET, socket.SOCK_STREAM); raw.settimeout(20); raw.connect(addr)
t = paramiko.Transport(ctx.wrap_socket(raw, server_hostname='a.pinggy.io'))
t.set_keepalive(20); t.start_client(timeout=20)
try: t.auth_none('tunnel')
except paramiko.BadAuthenticationType: t.auth_password('tunnel', '')
t.request_port_forward('', 0, handler=lambda ch, o, d: threading.Thread(target=pipe, args=(ch,), daemon=True).start())
sess = t.open_session(); sess.get_pty(); sess.exec_command('x:passpreflight')
buf = b''
while t.is_active():
    if sess.recv_ready():
        buf += sess.recv(4096)
        urls = [u.decode() for u in re.findall(rb'https://[a-z0-9.-]+\.(?:pinggy\.link|free\.pinggy\.link|a\.pinggy\.link|run\.pinggy-free\.link|pinggy-free\.link)', buf)]
        if urls:
            v4 = [u for u in urls if '--' not in u]
            put((v4 or urls)[-1])
    else: time.sleep(0.5)
print('tunnel fermé', flush=True)
