#!/bin/bash
# Publie l'URL du tunnel sur un topic ntfy.sh public : le dashboard GitHub Pages la découvre tout seul.
HERE="$(cd "$(dirname "$0")" && pwd)"; D="${SIM_DATA:-$HERE/data}"
TOPIC=$(tr -d '[:space:]' < "$HERE/ntfy_topic.txt")
last=""; lastt=0
while true; do
  u=$(tr -d '[:space:]' < "$D/public_url.txt" 2>/dev/null); n=$(date +%s)
  if [ -n "$u" ] && { [ "$u" != "$last" ] || [ $((n-lastt)) -ge 1800 ]; }; then
    c=$(curl -s -o /dev/null -w "%{http_code}" -m 15 -H "Title: kimchi-dash-url" -d "$u" "https://ntfy.sh/$TOPIC")
    echo "$(date '+%F %T') publish $u -> $c"
    if [ "$c" = "200" ]; then last="$u"; lastt=$n; else sleep 20; fi
  fi
  sleep 10
done
