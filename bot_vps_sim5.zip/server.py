#!/usr/bin/env python3
# Petit serveur API lecture seule pour le dashboard (CORS ouvert, données de SIMULATION uniquement).
import os, json
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.environ.get('SIM_DATA', os.path.join(HERE, 'data'))
PORT = int(os.environ.get('SIM_PORT', '8800'))
def rd(p):
    try:
        with open(p, 'rb') as f: return f.read()
    except Exception: return None
class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def cors(self):
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', '*')
        self.send_header('Access-Control-Allow-Private-Network', 'true')
    def out(self, code, body, ctype='application/json'):
        self.send_response(code); self.send_header('Content-Type', ctype); self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store'); self.cors(); self.end_headers(); self.wfile.write(body)
    def do_OPTIONS(self):
        self.send_response(204); self.cors(); self.send_header('Content-Length', '0'); self.end_headers()
    def do_GET(self):
        p = self.path.split('?')[0]
        if p in ('/snapshot', '/history'):
            b = rd(os.path.join(DATA, p[1:] + '.json'))
            self.out(200, b) if b else self.out(503, b'{"error":"no data yet"}')
        elif p == '/trades':
            # historique complet des trades (lecture seule, 3000 derniers) pour l'analyse des stratégies
            raw = rd(os.path.join(DATA, 'trades.jsonl')) or b''
            lines = [l for l in raw.decode('utf-8', 'replace').splitlines() if l.strip()][-3000:]
            self.out(200, ('[' + ','.join(lines) + ']').encode('utf-8'))
        elif p == '/health': self.out(200, b'{"ok":true}')
        elif p in ('/', '/index.html'):
            b = rd(os.path.join(HERE, 'dashboard', 'index.html')) or b'no dashboard'
            self.out(200, b, 'text/html; charset=utf-8')
        elif p.startswith('/static/') and '..' not in p:
            b = rd(os.path.join(HERE, 'dashboard', p[1:]))
            self.out(200, b, 'font/woff2') if b else self.out(404, b'{}')
        else: self.out(404, b'{}')
ThreadingHTTPServer(('0.0.0.0' if os.environ.get('SIM_BIND_ALL') else '127.0.0.1', PORT), H).serve_forever()
