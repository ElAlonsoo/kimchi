#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Grok Bot · Arène SIMULATION — 5 bots Pump.fun indépendants, 60 EUR fictifs chacun (300 EUR au total).
Mises en % du solde de chaque bot (s'adapte à n'importe quel capital).
100% PAPER TRADING : aucune clé privée, aucune signature, aucune transaction. Données de marché réelles :
  - PumpPortal WS (newToken / migration : détection des nouveaux coins en < 1 s, lecture seule, sans clé)
  - GeckoTerminal (découverte : pools pump.fun bonding-curve + PumpSwap, acheteurs/vendeurs uniques, variations)
  - DexScreener  (prix temps réel des positions et candidats, liquidité, txns m5/h1)
  - Binance      (SOL/EUR, SOL/USDT)
Frais/slippage simulés de façon réaliste (frais pump.fun / PumpSwap, frais réseau, impact de prix, latence).
Pause nuit : aucune NOUVELLE entrée entre 01:00 et 08:00 (Europe/Paris) ; les positions ouvertes restent gérées.
"""
import json, os, time, threading, urllib.request, urllib.error, traceback, math, random, sys
from collections import deque
from datetime import datetime
try:
    from zoneinfo import ZoneInfo
    TZ = ZoneInfo('Europe/Paris')
except Exception:
    TZ = None

if os.environ.get('PUMPBOTS_LIVE', '0') not in ('', '0'):
    sys.exit('Ce programme est SIMULATION uniquement (PUMPBOTS_LIVE doit valoir 0).')

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.environ.get('SIM_DATA', os.path.join(HERE, 'data'))
os.makedirs(DATA, exist_ok=True)
P = lambda f: os.path.join(DATA, f)
UA = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) simbot/1.0', 'Accept': 'application/json'}
WSOL = 'So11111111111111111111111111111111111111112'
START_EUR = 60.0             # 5 x 60 EUR = 300 EUR (capital réel prévu en janvier)
CODE_VERSION = 'sim5-2026-11-12-reset300'
RESET_FLAG = 'reset_300_v1'
TEST_END_TS = 1798758000     # 2027-01-01 00:00 heure de Paris
NIGHT = (1, 8)  # pas de nouvelles entrées de 01:00 à 08:00 heure de Paris

def now(): return time.time()
def paris(t=None):
    t = t or now()
    return datetime.fromtimestamp(t, TZ) if TZ else datetime.fromtimestamp(t)
def ts(t=None): return paris(t).strftime('%Y-%m-%d %H:%M:%S')
def night_pause(t=None):
    h = paris(t).hour
    return NIGHT[0] <= h < NIGHT[1]
def fnum(x, d=0.0):
    try:
        if x is None: return d
        v = float(x)
        return v if math.isfinite(v) else d
    except Exception: return d
def http_json(url, t=10):
    r = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(r, timeout=t) as f: return json.loads(f.read(4_000_000))

LOCK = threading.RLock()
SRC = {'geckoterminal': 'init', 'dexscreener': 'init', 'binance': 'init'}
STATS = {'gecko_calls': 0, 'gecko_err': 0, 'dex_calls': 0, 'dex_err': 0, 'tokens': 0, 'evals': 0}
FX = {'sol_eur': 0.0, 'sol_usd': 0.0}
TOK = {}           # mint -> token data
EVENTS = deque(maxlen=200)

def log_ev(kind, msg, bot=None, **kw):
    e = {'ts': ts(), 'epoch': round(now(), 1), 'type': kind, 'msg': msg}
    if bot: e['bot'] = bot
    e.update(kw)
    with LOCK: EVENTS.append(e)
    try:
        with open(P('events.jsonl'), 'a') as f: f.write(json.dumps(e, ensure_ascii=False) + '\n')
    except Exception: pass
    print(e['ts'], kind, bot or '', msg, flush=True)

# ---------------------------------------------------------------- market data
def tok(mint):
    t = TOK.get(mint)
    if t is None:
        t = TOK[mint] = {'mint': mint, 'sym': '?', 'name': '', 'dex': '', 'pool': '', 'created': 0, 'px_sol': 0.0, 'px_usd': 0.0,
                         'mcap': 0.0, 'liq': 0.0, 'liq_sol': 0.0, 'ch': {}, 'tx': {}, 'vol': {}, 'g_t': 0, 'd_t': 0, 'px_t': 0,
                         'hist': deque(maxlen=400), 'max10': deque(maxlen=200), 'seen': now(), 'migrated_at': 0}
    return t

GLITCH_RATIO = 8.0          # saut de prix max accepté sans confirmation
GLITCH_AGREE = 1.25         # sources / lectures « d'accord » si écart ≤ 25 %
GLITCH_CONFIRM_S = 60.0     # 3 lectures cohérentes sur au moins 60 s
MACE_MINT = 'AFkZHdMjC3BRt6XvriAxdowexuBghTHDRTTvihUkmGVu'
MACE_BOTS_CLOSE = ('Le Sélectionneur', 'Le Surfeur')

def preferred_pool(mint):
    """Adresse de pool/paire déjà retenue pour une position ouverte, sinon celle du token."""
    for b in STATE.get('bots', {}).values():
        for p in b.get('pos') or []:
            if p.get('mint') == mint and p.get('pool'):
                return p['pool']
    t = TOK.get(mint)
    return (t or {}).get('pool') or ''

def repin_pool(mint, pool):
    if not pool: return
    for b in STATE.get('bots', {}).values():
        for p in b.get('pos') or []:
            if p.get('mint') == mint and p.get('pool') != pool:
                p['pool'] = pool; p['dex'] = 'pumpswap'
                log_ev('pool', '%s a migré sur PumpSwap : la position suit le nouveau pool' % p.get('sym', '?'), b.get('name'), mint=mint)
    t = TOK.get(mint)
    if t: t['pool'] = pool; t['dex'] = 'pumpswap'; t['migrated_at'] = t.get('migrated_at') or now()

def _accept_px(t, px_sol, px_usd, src, pool=None):
    t['px_sol'] = px_sol
    t['px_usd'] = px_usd or (px_sol * FX['sol_usd'] if FX.get('sol_usd') else 0.0)
    t['px_t'] = now()
    t['px_src'] = src
    t['px_pend'] = []
    if pool: t['pool'] = pool
    t['hist'].append((now(), px_sol))

def set_px(t, px_sol, px_usd, src, pool=None):
    """Enregistre un prix. Rejette px <= 0 et les sauts irréalistes (x8 ou /8) tant qu'ils
    ne sont pas confirmés par une 2e source (Gecko vs Dex) ou 3 lectures cohérentes sur >= 60 s."""
    if px_sol <= 0 and px_usd > 0 and FX['sol_usd'] > 0: px_sol = px_usd / FX['sol_usd']
    if px_sol <= 0: return False
    last = fnum(t.get('px_sol'))
    if last <= 0:
        _accept_px(t, px_sol, px_usd, src, pool); return True
    ratio = px_sol / last
    if src == 'pp' and t.get('dex') == 'pump-fun':
        _accept_px(t, px_sol, px_usd, src, pool); return True   # état on-chain de la courbe : fiable
    if 1.0 / GLITCH_RATIO <= ratio <= GLITCH_RATIO:
        _accept_px(t, px_sol, px_usd, src, pool); return True
    # Saut anormal : on attend une confirmation, on garde le dernier prix valide.
    pend = t.setdefault('px_pend', [])
    pend.append({'t': now(), 'px': px_sol, 'src': src, 'pool': pool or ''})
    pend[:] = [x for x in pend if now() - x['t'] <= 300]
    accepted = False
    by_src = {}
    for x in pend:
        by_src[x['src']] = x
    if 'gecko' in by_src and 'dex' in by_src:
        a, b = by_src['gecko']['px'], by_src['dex']['px']
        if a > 0 and b > 0 and max(a, b) / min(a, b) <= GLITCH_AGREE:
            accepted = True
            px_sol = (a + b) / 2.0
    if not accepted and len(pend) >= 3:
        last3 = pend[-3:]
        pxs = [x['px'] for x in last3]
        span = last3[-1]['t'] - last3[0]['t']
        if min(pxs) > 0 and max(pxs) / min(pxs) <= GLITCH_AGREE and span >= GLITCH_CONFIRM_S:
            accepted = True
            px_sol = pxs[-1]
    if accepted:
        _accept_px(t, px_sol, px_usd, src, pool); return True
    if now() - t.get('glitch_log_t', 0) > 60:
        t['glitch_log_t'] = now()
        log_ev('px', 'prix ignoré pour %s : saut x%.1f (%.3g → %.3g), confirmation requise' % (t.get('sym') or t.get('mint','')[:8], ratio, last, px_sol))
    return False

def parse_gecko_pool(p, inc):
    a = p.get('attributes', {}); rel = p.get('relationships', {})
    dex = ((rel.get('dex') or {}).get('data') or {}).get('id', '')
    if dex not in ('pump-fun', 'pumpswap'): return
    q = ((rel.get('quote_token') or {}).get('data') or {}).get('id', '')
    if q and q != 'solana_' + WSOL: return
    b = ((rel.get('base_token') or {}).get('data') or {}).get('id', '')
    if not b.startswith('solana_'): return
    mint = b[7:]
    if mint == WSOL: return
    with LOCK:
        t = tok(mint)
        if dex == 'pumpswap' and t['dex'] == 'pump-fun': t['migrated_at'] = now()
        if dex == 'pump-fun' and t['dex'] == 'pumpswap': return  # garder le pool PumpSwap une fois migré
        pref = preferred_pool(mint)
        addr = a.get('address') or ''
        if pref and addr and addr != pref and dex != 'pumpswap':
            return  # ne pas remplacer le pool d'une position ouverte
        old_dex = t['dex']
        t['dex'] = dex
        if addr and (not pref or addr == pref or (dex == 'pumpswap' and old_dex != 'pumpswap')):
            t['pool'] = addr
        nm = (a.get('name') or '').split(' / ')[0]
        if nm: t['sym'] = nm[:16]
        inf = inc.get(b)
        if inf: t['sym'] = (inf.get('symbol') or t['sym'])[:16]; t['name'] = inf.get('name') or ''
        try: t['created'] = datetime.fromisoformat(a['pool_created_at'].replace('Z', '+00:00')).timestamp()
        except Exception: pass
        if dex == 'pumpswap' and not t['migrated_at']: t['migrated_at'] = t['created']
        t['ch'] = {k: fnum(v) for k, v in (a.get('price_change_percentage') or {}).items()}
        t['tx'] = {k: {'b': int(fnum(v.get('buys'))), 's': int(fnum(v.get('sells'))), 'bu': int(fnum(v.get('buyers'))), 'se': int(fnum(v.get('sellers')))}
                   for k, v in (a.get('transactions') or {}).items()}
        t['vol'] = {k: fnum(v) for k, v in (a.get('volume_usd') or {}).items()}
        t['mcap'] = fnum(a.get('market_cap_usd')) or fnum(a.get('fdv_usd'))
        r = fnum(a.get('reserve_in_usd'))
        if r: t['liq'] = r
        t['g_t'] = now()
        addr = a.get('address') or ''
        pref = preferred_pool(mint)
        if pref and addr and addr != pref:
            pass  # autre pool : on ne touche pas au prix de la position
        else:
            if addr and not pref:
                t['pool'] = addr
            if now() - t['px_t'] > 20 or not t.get('px_sol'):
                set_px(t, fnum(a.get('base_token_price_native_currency')), fnum(a.get('base_token_price_usd')), 'gecko', pool=addr or None)

GECKO_ROT = [
    'networks/solana/new_pools?page=1&include=base_token,dex,quote_token',
    'networks/solana/dexes/pump-fun/pools?page=1&sort=h24_tx_count_desc&include=base_token,dex,quote_token',
    'networks/solana/dexes/pumpswap/pools?page=1&sort=h24_volume_usd_desc&include=base_token,dex,quote_token',
    'networks/solana/trending_pools?page=1&duration=5m&include=base_token,dex,quote_token',
    'networks/solana/new_pools?page=2&include=base_token,dex,quote_token',
    'networks/solana/dexes/pumpswap/pools?page=2&sort=h24_volume_usd_desc&include=base_token,dex,quote_token',
    'networks/solana/trending_pools?page=1&duration=1h&include=base_token,dex,quote_token',
    'networks/solana/dexes/pump-fun/pools?page=2&sort=h24_tx_count_desc&include=base_token,dex,quote_token',
    'networks/solana/new_pools?page=1&include=base_token,dex,quote_token',
    'networks/solana/dexes/pumpswap/pools?page=1&sort=h24_tx_count_desc&include=base_token,dex,quote_token',
    'networks/solana/trending_pools?page=2&duration=5m&include=base_token,dex,quote_token',
    'networks/solana/dexes/pumpswap/pools?page=3&sort=h24_volume_usd_desc&include=base_token,dex,quote_token',
    'networks/solana/trending_pools?page=1&duration=6h&include=base_token,dex,quote_token',
    'networks/solana/dexes/pump-fun/pools?page=1&sort=h24_volume_usd_desc&include=base_token,dex,quote_token',
]
GECKO_BASE_S = 7.0   # API publique GeckoTerminal : ~10 req/min max, sinon HTTP 429
def gecko_loop():
    i = 0; back = GECKO_BASE_S; fails = 0
    while True:
        u = 'https://api.geckoterminal.com/api/v2/' + GECKO_ROT[i % len(GECKO_ROT)]
        try:
            STATS['gecko_calls'] += 1
            d = http_json(u, 12)
            inc = {x['id']: x.get('attributes', {}) for x in d.get('included', []) if x.get('type') == 'token'}
            for p in d.get('data', []): parse_gecko_pool(p, inc)
            SRC['geckoterminal'] = 'ok'; fails = 0; i += 1
            back = max(GECKO_BASE_S, back * 0.8)       # on redescend doucement après un 429
        except urllib.error.HTTPError as e:
            STATS['gecko_err'] += 1; SRC['geckoterminal'] = f'HTTP {e.code} (DexScreener prend le relais)'
            fails += 1
            if e.code == 429:
                ra = fnum((e.headers or {}).get('Retry-After'), 0) if hasattr(e, 'headers') else 0
                back = min(180.0, max(back * 2, ra, 15.0))  # même requête retentée après la pause
            else:
                i += 1; back = min(60.0, back * 1.5)
        except Exception as e:
            STATS['gecko_err'] += 1; SRC['geckoterminal'] = 'erreur ' + str(e)[:60]; i += 1
            back = min(60.0, back * 1.5)
        cleanup_tokens()
        time.sleep(back + random.uniform(0, 1.5))

def cleanup_tokens():
    with LOCK:
        held = held_mints(); tn = now()
        drop = []
        for m, t in TOK.items():
            if m in held: continue
            last = max(t['g_t'], t['d_t'], t.get('pp_t', 0), t['seen'])
            if last < tn - 3 * 3600: drop.append(m)
            elif not t['g_t'] and t.get('pp_t') and tn - t['seen'] > 25 * 60 and not dex_active(t): drop.append(m)
        for m in drop: TOK.pop(m, None)
        STATS['tokens'] = len(TOK)

def _dex_pair_ok(p):
    if p.get('chainId') != 'solana': return False
    if (p.get('quoteToken') or {}).get('address') != WSOL: return False
    if p.get('dexId') not in ('pumpfun', 'pumpswap'): return False
    return bool((p.get('baseToken') or {}).get('address'))

def _pick_dex_pair(mint, plist):
    """Choisit la paire DexScreener : d'abord celle du pool stocké, sinon la plus pertinente."""
    pref = preferred_pool(mint)
    if pref:
        for p in plist:
            if p.get('pairAddress') == pref:
                if p.get('dexId') == 'pumpfun':
                    # la courbe est terminée et le coin a migré : son prix est figé, on suit le pool PumpSwap
                    amm = [x for x in plist if x.get('dexId') == 'pumpswap' and fnum((x.get('liquidity') or {}).get('usd')) > 0]
                    if amm:
                        new = max(amm, key=lambda x: fnum((x.get('liquidity') or {}).get('usd')))
                        repin_pool(mint, new.get('pairAddress') or '')
                        return new
                return p
    best = None
    for p in plist:
        lq = fnum((p.get('liquidity') or {}).get('usd'))
        if best is None or (p.get('dexId') == 'pumpswap' and best.get('dexId') != 'pumpswap') or lq > fnum((best.get('liquidity') or {}).get('usd')):
            best = p
    return best

def dex_apply(pairs):
    by_mint = {}
    for p in pairs or []:
        if not _dex_pair_ok(p): continue
        m = (p.get('baseToken') or {}).get('address')
        by_mint.setdefault(m, []).append(p)
    with LOCK:
        for m, plist in by_mint.items():
            p = _pick_dex_pair(m, plist)
            if not p: continue
            t = tok(m)
            t['sym'] = ((p.get('baseToken') or {}).get('symbol') or t['sym'])[:16]
            dx = 'pumpswap' if p.get('dexId') == 'pumpswap' else 'pump-fun'
            if dx == 'pumpswap' and t['dex'] == 'pump-fun': t['migrated_at'] = now()
            t['dex'] = dx
            pair = p.get('pairAddress') or ''
            pref = preferred_pool(m)
            if pair and (not pref or pair == pref or (dx == 'pumpswap' and t.get('pool') != pair)):
                if not pref or pair == pref:
                    t['pool'] = pair
            l = p.get('liquidity') or {}
            if fnum(l.get('usd')): t['liq'] = fnum(l.get('usd'))
            if fnum(l.get('quote')): t['liq_sol'] = fnum(l.get('quote'))
            t['mcap'] = fnum(p.get('marketCap')) or fnum(p.get('fdv')) or t['mcap']
            t['dtx'] = {k: {'b': int(fnum(v.get('buys'))), 's': int(fnum(v.get('sells')))} for k, v in (p.get('txns') or {}).items()}
            t['dch'] = {k: fnum(v) for k, v in (p.get('priceChange') or {}).items()}
            t['dvol'] = {k: fnum(v) for k, v in (p.get('volume') or {}).items()}
            if not t['created'] and p.get('pairCreatedAt'): t['created'] = fnum(p['pairCreatedAt']) / 1000
            t['d_t'] = now()
            # Prix seulement si la paire correspond au pool de la position (quand il est connu)
            if pref and pair and pair != pref:
                continue
            set_px(t, fnum(p.get('priceNative')), fnum(p.get('priceUsd')), 'dex', pool=pair or None)

def dex_loop():
    while True:
        try:
            with LOCK:
                held = list(held_mints())
                cands = sorted([t for t in TOK.values() if t['mint'] not in held and pre_ok(t)], key=lambda t: -t['g_t'])
                want = held + [t['mint'] for t in cands if now() - t['d_t'] > 4][:max(0, 60 - len(held))]
                # jeunes coins détectés par PumpPortal (âge 40 s - 16 min) : actifs à chaque tour, les autres en tourniquet
                young = [t for t in TOK.values() if t.get('pp_t') and t['mint'] not in held and t['dex'] == 'pump-fun'
                         and 40 <= now() - t['created'] <= 16 * 60 and t['mint'] not in want]
                act = sorted([t for t in young if dex_active(t)], key=lambda t: t['d_t'])
                idle = sorted([t for t in young if not dex_active(t)], key=lambda t: t['d_t'])
                want += [t['mint'] for t in act if now() - t['d_t'] > 3][:60]
                want += [t['mint'] for t in idle][:max(0, 150 - len(want))]
            for k in range(0, min(len(want), 150), 30):
                chunk = want[k:k + 30]
                try:
                    d = http_json('https://api.dexscreener.com/tokens/v1/solana/' + ','.join(chunk), 10); STATS['dex_calls'] += 1
                    dex_apply(d if isinstance(d, list) else d.get('pairs'))
                    SRC['dexscreener'] = 'ok'
                except Exception as e:
                    STATS['dex_err'] += 1; SRC['dexscreener'] = 'erreur ' + str(e)[:60]
                time.sleep(0.4)
        except Exception: traceback.print_exc()
        time.sleep(2.0)

PP_URL = 'wss://pumpportal.fun/api/data'
def pp_loop():
    """Flux public PumpPortal (sans clé) : création de coins + migrations, en temps réel."""
    try:
        import websocket
    except Exception:
        SRC['pumpportal'] = 'module websocket absent'; return
    back = 2.0
    while True:
        ws = None
        try:
            ws = websocket.create_connection(PP_URL, timeout=30)
            ws.send(json.dumps({'method': 'subscribeNewToken'}))
            ws.send(json.dumps({'method': 'subscribeMigration'}))
            SRC['pumpportal'] = 'ok'; back = 2.0
            while True:
                try:
                    raw = ws.recv()
                except websocket.WebSocketTimeoutException:
                    ws.ping(); continue
                if not raw: raise ConnectionError('flux fermé')
                try: m = json.loads(raw)
                except Exception: continue
                pp_handle(m)
        except Exception as e:
            SRC['pumpportal'] = 'reconnexion (' + str(e)[:40] + ')'
        finally:
            try: ws and ws.close()
            except Exception: pass
        time.sleep(back + random.uniform(0, 1)); back = min(60.0, back * 2)

def pp_handle(m):
    mint = m.get('mint') or ''
    if not mint or not isinstance(mint, str) or mint == WSOL: return
    kind = m.get('txType')
    with LOCK:
        if kind == 'create' and (m.get('pool') in (None, 'pump')):
            STATS['pp_new'] = STATS.get('pp_new', 0) + 1
            t = tok(mint)
            t['pp_t'] = now()
            if not t['created']: t['created'] = now()
            if not t['dex']: t['dex'] = 'pump-fun'
            sym = (m.get('symbol') or '').strip()
            if sym: t['sym'] = sym[:16]
            t['name'] = (m.get('name') or '')[:40]
            vs, vt = fnum(m.get('vSolInBondingCurve')), fnum(m.get('vTokensInBondingCurve'))
            if vs > 0: t['liq_sol'] = vs
            if FX.get('sol_usd') and fnum(m.get('marketCapSol')) > 0: t['mcap'] = fnum(m['marketCapSol']) * FX['sol_usd']
            if vs > 0 and vt > 0 and t['dex'] == 'pump-fun': set_px(t, vs / vt, 0.0, 'pp')
        elif kind == 'migrate' or m.get('txType') is None and m.get('signature') and m.get('pool') in ('pump-amm', 'pumpswap'):
            STATS['pp_mig'] = STATS.get('pp_mig', 0) + 1
            t = TOK.get(mint)
            if t:
                t['migrated_at'] = now(); t['pp_t'] = t.get('pp_t') or now()

def fx_loop():
    while True:
        try:
            e = http_json('https://data-api.binance.vision/api/v3/ticker/price?symbol=SOLEUR', 8)
            u = http_json('https://data-api.binance.vision/api/v3/ticker/price?symbol=SOLUSDT', 8)
            FX['sol_eur'] = fnum(e['price']); FX['sol_usd'] = fnum(u['price']); SRC['binance'] = 'ok'
        except Exception as ex:
            SRC['binance'] = 'erreur ' + str(ex)[:50]
        time.sleep(10)

# ---------------------------------------------------------------- helpers on token stats
def age_min(t): return (now() - t['created']) / 60 if t['created'] else -1
def txw(t, w): return t['tx'].get(w) or {'b': 0, 's': 0, 'bu': 0, 'se': 0}
def ratio(a, b): return a / b if b > 0 else (9.9 if a > 0 else 0)
def micro_ok(t, secs=40, tol=0.03):
    """pas de chute dans les dernières secondes (prix actuel >= max récent * (1-tol))"""
    h = [p for (tt, p) in t['hist'] if now() - tt <= secs]
    if len(h) < 2: return True
    return h[-1] >= max(h) * (1 - tol)
def rugged(t):
    h = [p for (tt, p) in t['hist'] if now() - tt <= 900]
    return len(h) >= 2 and h[-1] < max(h) * 0.45
def fresh(t, s=12): return now() - t['px_t'] <= s and t['px_sol'] > 0 and now() - t['d_t'] <= s
def dex_active(t):
    d5 = (t.get('dtx') or {}).get('m5') or {}
    return d5.get('b', 0) >= 10
def pre_ok(t):
    """pré-filtre large : vaut-il la peine de rafraîchir ce token sur DexScreener ?"""
    if not t['g_t'] or now() - t['g_t'] > 900: return False
    tx5 = txw(t, 'm5'); tx1 = txw(t, 'h1')
    return (tx5['bu'] >= 8 or tx1['bu'] >= 60) and t['mcap'] >= 6000

# ---------------------------------------------------------------- strategies
def red_flags(t):
    if rugged(t): return 'chute >55% en 15 min (rug?)'
    d5 = (t.get('dtx') or {}).get('m5') or {'b': 0, 's': 0}
    if d5['s'] > 3 * max(1, d5['b']) and d5['s'] > 15: return 'ventes massives m5'
    if t['dex'] == 'pumpswap' and t['mcap'] > 0 and t['liq'] / t['mcap'] < 0.04: return 'liquidité trop faible vs mcap'
    if t['sym'] in ('?', '') : return 'symbole inconnu'
    return ''

def s_quality(t):
    a = age_min(t); m5 = txw(t, 'm5'); h1 = txw(t, 'h1'); ch = t['ch']
    if not (20 <= a <= 24 * 60): return 0, 'âge'
    if not (40e3 <= t['mcap'] <= 5e6): return 0, 'mcap'
    if t['liq'] < 15e3: return 0, 'liquidité'
    if t['vol'].get('h1', 0) < 25e3: return 0, 'volume h1'
    if h1['bu'] < 60 or ratio(h1['bu'], h1['se']) < 1.15: return 0, 'acheteurs h1'
    if m5['bu'] < 8 or m5['bu'] < m5['se']: return 0, 'acheteurs m5'
    if not (0 < ch.get('m5', 0) <= 15): return 0, 'm5'
    if not (5 <= ch.get('h1', 0) <= 120) or ch.get('m30', 0) <= 0: return 0, 'tendance h1/m30'
    if not micro_ok(t): return 0, 'micro-chute'
    return 50 + min(30, h1['bu'] / 10) + 10 * min(2, ratio(h1['bu'], h1['se'])) + min(10, t['liq'] / 1e4), 'qualité: %d acheteurs/h, x%.2f ach/vend, liq %.0fk$' % (h1['bu'], ratio(h1['bu'], h1['se']), t['liq'] / 1e3)

def s_migration(t):
    if t['dex'] != 'pumpswap': return 0, 'pas migré'
    mig = t['migrated_at'] or t['created']
    am = (now() - mig) / 60 if mig else -1
    if not (3 <= am <= 90): return 0, 'âge migration'
    m15 = txw(t, 'm15'); h1 = txw(t, 'h1'); ch = t['ch']
    if t['liq'] < 12e3 or not (50e3 <= t['mcap'] <= 2e6): return 0, 'liq/mcap'
    if h1['bu'] < 50 or ratio(m15['bu'], m15['se']) < 1.1: return 0, 'acheteurs'
    if ch.get('m5', 0) <= 0 or ch.get('m15', 0) < -10 or ch.get('h1', 0) > 200: return 0, 'momentum'
    if not micro_ok(t): return 0, 'micro-chute'
    return 55 + min(30, h1['bu'] / 8) + 10 * min(2, ratio(m15['bu'], m15['se'])), 'migré il y a %d min, %d acheteurs/h' % (am, h1['bu'])

def s_sniper(t):
    if t['dex'] != 'pump-fun': return 0, 'pas sur la courbe'
    if not t['g_t'] or now() - t['g_t'] > 120:
        return s_sniper_dex(t)
    a = age_min(t); m5 = txw(t, 'm5'); ch = t['ch']
    if not (2 <= a <= 15): return 0, 'âge'
    if not (7e3 <= t['mcap'] <= 40e3): return 0, 'mcap'
    if m5['bu'] < 25 or ratio(m5['bu'], m5['se']) < 1.6: return 0, 'acheteurs m5'
    if t['vol'].get('m5', 0) < 3e3: return 0, 'volume m5'
    if not (5 <= ch.get('m5', 0) <= 80): return 0, 'm5'
    if not micro_ok(t, 30, 0.04): return 0, 'micro-chute'
    return 50 + min(30, m5['bu'] / 3) + 10 * min(2, ratio(m5['bu'], m5['se'])), 'jeune %.0f min, %d acheteurs/5min x%.1f' % (a, m5['bu'], ratio(m5['bu'], m5['se']))

def s_sniper_dex(t):
    """Version « temps réel » : coin vu à la création via PumpPortal, stats m5 DexScreener (nb d'achats/ventes)."""
    if not t.get('pp_t'): return 0, 'pas de données récentes'
    a = age_min(t); d5 = (t.get('dtx') or {}).get('m5') or {'b': 0, 's': 0}
    if not (2 <= a <= 15): return 0, 'âge'
    if not (7e3 <= t['mcap'] <= 40e3): return 0, 'mcap'
    if d5['b'] < 40 or ratio(d5['b'], d5['s']) < 1.6: return 0, 'achats m5'
    if (t.get('dvol') or {}).get('m5', 0) < 3e3: return 0, 'volume m5'
    chm5 = (t.get('dch') or {}).get('m5', 0)
    if not (5 <= chm5 <= 80): return 0, 'm5'
    if not micro_ok(t, 30, 0.04): return 0, 'micro-chute'
    return 48 + min(30, d5['b'] / 4) + 10 * min(2, ratio(d5['b'], d5['s'])), 'jeune %.0f min (détecté à la création), %d achats/5min x%.1f' % (a, d5['b'], ratio(d5['b'], d5['s']))

def s_dip(t):
    a = age_min(t); m5 = txw(t, 'm5'); ch = t['ch']
    if a < 360: return 0, 'âge'
    if t['liq'] < 30e3 or not (150e3 <= t['mcap'] <= 30e6): return 0, 'liq/mcap'
    if t['vol'].get('h24', 0) < 150e3: return 0, 'volume 24h'
    if ch.get('h24', 0) < 15 and ch.get('h6', 0) < 10: return 0, 'pas de tendance de fond'
    if not (-45 <= ch.get('h1', 0) <= -12): return 0, 'pas de creux h1'
    if ch.get('m5', 0) < 1.5 or m5['bu'] <= m5['se']: return 0, 'pas de rebond'
    # rebond m5 confirmé : prix en hausse sur 5 min et plus d'achats que de ventes (gecko + dex si dispo)
    h5 = [px for (tt, px) in t['hist'] if now() - tt <= 300]
    if len(h5) >= 2 and h5[-1] <= h5[0]: return 0, 'rebond non confirmé (prix 5 min)'
    d5 = (t.get('dtx') or {}).get('m5') or {}
    if d5 and d5.get('b', 0) <= d5.get('s', 0): return 0, 'rebond non confirmé (dex)'
    if not micro_ok(t, 40, 0.02): return 0, 'micro-chute'
    return 50 + min(25, -ch['h1']) + min(15, t['liq'] / 2e4), 'creux %.0f%% h1 sur tendance +%.0f%% 24h, rebond m5' % (ch['h1'], ch.get('h24', 0))

def s_trend(t):
    a = age_min(t); h1 = txw(t, 'h1'); ch = t['ch']
    if a < 120: return 0, 'âge'
    if not (300e3 <= t['mcap'] <= 50e6) or t['liq'] < 50e3: return 0, 'liq/mcap'
    if not (8 <= ch.get('h1', 0) <= 70) or ch.get('h6', 0) <= 10 or ch.get('m15', 0) <= 0: return 0, 'tendance'
    if not (0 <= ch.get('m5', 0) <= 10): return 0, 'm5 (pas de poursuite de pic)'
    if h1['bu'] < 150 or ratio(h1['bu'], h1['se']) < 1.1 or t['vol'].get('h1', 0) < 50e3: return 0, 'flux acheteurs'
    if not micro_ok(t, 40, 0.02): return 0, 'micro-chute'
    return 50 + min(25, ch['h1'] / 2) + min(20, h1['bu'] / 30), 'breakout +%.0f%% h1 / +%.0f%% 6h, %d acheteurs/h' % (ch['h1'], ch['h6'], h1['bu'])

BOTS_CFG = [
    {'name': 'Le Sélectionneur', 'emoji': '💎', 'col': '#22e4ff', 'fn': s_quality,
     'blurb': 'Ne prend que les meilleurs coins : beaucoup de vrais acheteurs, volume, liquidité, tendance saine.',
     'size': 0.22, 'maxpos': 2, 'sl': -0.14, 'tp': [(0.25, 0.50), (0.60, 0.25)], 'arm': 0.25, 'trail': 0.12, 'tmax': 7200, 'tmin': 0.05, 'cool': 180},
    {'name': 'Le Diplômé', 'emoji': '🎓', 'col': '#b44dff', 'fn': s_migration,
     'blurb': 'Coins qui viennent de terminer la bonding curve et de migrer sur PumpSwap, avec flux acheteur.',
     'size': 0.20, 'maxpos': 2, 'sl': -0.16, 'tp': [(0.35, 0.50), (0.80, 0.25)], 'arm': 0.35, 'trail': 0.15, 'tmax': 5400, 'tmin': 0.05, 'cool': 180},
    {'name': 'Le Sniper', 'emoji': '🎯', 'col': '#ff4fd8', 'fn': s_sniper,
     'blurb': 'Coins très jeunes (2-15 min) sur la courbe, filtres stricts, petites mises.',
     'size': 0.08, 'maxpos': 3, 'sl': -0.20, 'tp': [(0.50, 0.50), (1.20, 0.30)], 'arm': 0.50, 'trail': 0.20, 'tmax': 1200, 'tmin': 0.10, 'cool': 120},
    {'name': 'Le Chasseur de Creux', 'emoji': '🪝', 'col': '#39ff88', 'fn': s_dip,
     'blurb': 'Achète les creux (-12 à -45 % sur 1h) de coins établis en tendance haussière, au rebond confirmé (prix 5 min + acheteurs).',
     'size': 0.20, 'maxpos': 2, 'sl': -0.15, 'tp': [(0.12, 0.50), (0.25, 0.25)], 'arm': 0.12, 'trail': 0.08, 'tmax': 10800, 'tmin': 0.03, 'cool': 300},
    {'name': 'Le Surfeur', 'emoji': '🏄', 'col': '#ffd23f', 'fn': s_trend,
     'blurb': 'Suit les tendances des gros coins (300k-50M$) en breakout confirmé, sans poursuivre les pics.',
     'size': 0.20, 'maxpos': 2, 'sl': -0.12, 'tp': [(0.20, 0.50), (0.45, 0.25)], 'arm': 0.20, 'trail': 0.10, 'tmax': 14400, 'tmin': 0.03, 'cool': 300},
]
CFG = {b['name']: b for b in BOTS_CFG}

# ---------------------------------------------------------------- paper execution model
FEE = {'pump-fun': 0.0125, 'pumpswap': 0.0100}   # frais de swap (protocole + créateur / LP)
NET_FEE_SOL = 0.00025                            # frais réseau + priorité par transaction
LAT_SLIP = {'pump-fun': 0.010, 'pumpswap': 0.005} # glissement dû à la latence
def slip(t, size_sol):
    liq = t['liq_sol'] or (t['liq'] / 2 / FX['sol_usd'] if FX['sol_usd'] else 0) or 30.0
    if t['dex'] == 'pump-fun': liq = max(liq, 30.0)  # réserves virtuelles de la courbe
    return LAT_SLIP.get(t['dex'], 0.01) + size_sol / max(liq, 1.0)

def eur_to_sol(e): return e / FX['sol_eur']

STATE = {'version': 1, 'start': None, 'bots': {}, 'trades': [], 'seq': 0}
def new_bot(n):
    return {'name': n, 'cash': START_EUR, 'start_eur': START_EUR, 'pos': [], 'realized': 0.0, 'fees': 0.0, 'trades': 0, 'wins': 0, 'losses': 0,
            'last_entry': 0, 'bans': {}, 'last_reason': '', 'best': None, 'worst': None}
def held_mints():
    s = set()
    for b in STATE['bots'].values():
        for p in b['pos']: s.add(p['mint'])
    return s

def pos_value_eur(p):
    t = TOK.get(p['mint'])
    px = t['px_sol'] if t and t.get('px_sol') and t['px_sol'] > 0 else fnum(p.get('last_px'))
    if px <= 0 or FX.get('sol_eur', 0) <= 0: return 0.0, px
    return p['qty'] * px * FX['sol_eur'], px

def bot_equity(b):
    return b['cash'] + sum(pos_value_eur(p)[0] * (1 - FEE.get(p['dex'], 0.01)) for p in b['pos'])

def record_trade(bot, side, t, p, eur, pnl=None, reason=''):
    STATE['seq'] += 1
    r = {'id': STATE['seq'], 'ts': ts(), 'epoch': round(now(), 1), 'bot': bot, 'side': side, 'sym': t['sym'], 'mint': t['mint'], 'dex': t['dex'],
         'px_sol': p, 'eur': round(eur, 4), 'pnl_eur': None if pnl is None else round(pnl, 4), 'reason': reason}
    STATE['trades'].append(r); del STATE['trades'][:-400]
    try:
        with open(P('trades.jsonl'), 'a') as f: f.write(json.dumps(r, ensure_ascii=False) + '\n')
    except Exception: pass

def buy(b, c, t, score, why):
    size_eur = round(min(b['cash'], max(1.0, bot_equity(b) * c['size'])), 4)
    if size_eur < 1.0 or b['cash'] < 1.0: return False
    size_sol = eur_to_sol(size_eur)
    sp = slip(t, size_sol); px = t['px_sol'] * (1 + sp)
    fee_sol = size_sol * FEE[t['dex']] + NET_FEE_SOL
    if t['px_sol'] <= 0 or FX.get('sol_eur', 0) <= 0: return False
    qty = (size_sol - fee_sol) / px
    if qty <= 0: return False
    b['cash'] -= size_eur; b['fees'] += fee_sol * FX['sol_eur']; b['last_entry'] = now()
    p = {'mint': t['mint'], 'sym': t['sym'], 'dex': t['dex'], 'pool': t.get('pool') or '', 'qty': qty, 'qty0': qty, 'entry_px': t['px_sol'], 'fill_px': px, 'cost_eur': size_eur,
         'opened': now(), 'peak': t['px_sol'], 'tp_done': [], 'last_px': t['px_sol'], 'realized': 0.0, 'why': why}
    b['pos'].append(p)
    record_trade(b['name'], 'BUY', t, px, size_eur, None, why)
    log_ev('buy', f"ACHAT {t['sym']} {size_eur:.2f}€ ({why})", b['name'], mint=t['mint'], eur=round(size_eur, 2))
    return True

def sell(b, p, frac, reason):
    t = TOK.get(p['mint']) or tok(p['mint'])
    q = p['qty'] if frac >= 0.999 else min(p['qty'], p['qty0'] * frac)
    if q <= 0: return False
    mid = t['px_sol'] if t and t.get('px_sol') and t['px_sol'] > 0 else 0.0
    if mid <= 0 or FX.get('sol_eur', 0) <= 0:
        if now() - p.get('sell_skip_log_t', 0) > 60:
            p['sell_skip_log_t'] = now()
            log_ev('skip', 'vente %s reportée : pas de prix valide (on garde la position)' % p.get('sym','?'), b['name'], mint=p['mint'])
        return False
    sol_out_mid = q * mid
    sp = slip(t, sol_out_mid)
    sol = sol_out_mid * (1 - sp) * (1 - FEE.get(p['dex'], 0.01)) - NET_FEE_SOL
    sol = max(0.0, sol)
    eur = sol * FX['sol_eur']
    cost = p['cost_eur'] * (q / p['qty0'])
    pnl = eur - cost
    b['fees'] += (sol_out_mid * FEE.get(p['dex'], 0.01) + NET_FEE_SOL) * FX['sol_eur']
    b['cash'] += eur; p['qty'] -= q; p['realized'] += pnl; b['realized'] += pnl
    closed = p['qty'] <= p['qty0'] * 1e-6
    record_trade(b['name'], 'SELL' if closed else 'TP', t, mid, eur, pnl, reason)
    log_ev('sell', f"{'VENTE' if closed else 'VENTE PARTIELLE'} {p['sym']} {int(round(frac*100)) if not closed or frac<0.999 else 100}% → {eur:.2f}€ ({pnl:+.2f}€) · {reason}", b['name'], mint=p['mint'], pnl_eur=round(pnl, 3))
    if closed:
        b['pos'].remove(p); b['trades'] += 1
        tot = p['realized']; pct = tot / p['cost_eur'] * 100
        if tot >= 0: b['wins'] += 1
        else: b['losses'] += 1
        if b['best'] is None or pct > b['best']['pct']: b['best'] = {'sym': p['sym'], 'pct': round(pct, 1)}
        if b['worst'] is None or pct < b['worst']['pct']: b['worst'] = {'sym': p['sym'], 'pct': round(pct, 1)}
        b['bans'][p['mint']] = now() + (24 * 3600 if 'stop-loss' in reason else 2 * 3600)

def manage(b, c):
    for p in list(b['pos']):
        t = TOK.get(p['mint'])
        if not t or not t['px_sol']:
            continue
        px = t['px_sol']; p['last_px'] = px
        if now() - t['px_t'] > 90:                   # prix trop vieux : on attend une donnée fraîche...
            # ...sauf si plus aucune donnée depuis 30 min et temps max dépassé (coin mort / délisté)
            if now() - t['px_t'] > 1800 and now() - p['opened'] > c['tmax']:
                sell(b, p, 1.0, 'plus de données de prix depuis 30 min (coin mort ?)')
            continue
        p['peak'] = max(p['peak'], px)
        g = px / p['entry_px'] - 1
        sl = c['sl'] if not p['tp_done'] else max(c['sl'], -0.02)   # après le 1er TP : stop au prix d'entrée
        if g <= sl:
            sell(b, p, 1.0, ('stop-loss %.0f%%' % (c['sl'] * 100)) if not p['tp_done'] else 'stop break-even'); continue
        for i, (lvl, fr) in enumerate(c['tp']):
            if i not in p['tp_done'] and g >= lvl:
                p['tp_done'].append(i); sell(b, p, fr, 'take-profit +%d%%' % (lvl * 100))
        if p not in b['pos']: continue
        pk = p['peak'] / p['entry_px'] - 1
        if pk >= c['arm'] and px <= p['peak'] * (1 - c['trail']):
            sell(b, p, 1.0, 'stop suiveur -%d%% depuis le sommet (+%.0f%%)' % (c['trail'] * 100, pk * 100)); continue
        if now() - p['opened'] > c['tmax'] and g < c['tmin']:
            sell(b, p, 1.0, 'temps max %d min' % (c['tmax'] / 60)); continue

def scan(b, c):
    if night_pause(): b['last_reason'] = 'pause nuit (01h-08h)'; return
    if len(b['pos']) >= c['maxpos']: b['last_reason'] = 'positions max'; return
    if now() - b['last_entry'] < c['cool']: b['last_reason'] = 'cooldown'; return
    if b['cash'] < 1.0: b['last_reason'] = 'cash < 1€'; return
    if FX['sol_eur'] <= 0: return
    best = None
    if len(b['bans']) > 300: b['bans'] = {m: e for m, e in b['bans'].items() if e > now()}
    held = {p['mint'] for p in b['pos']}
    for t in list(TOK.values()):
        if t['mint'] in held or b['bans'].get(t['mint'], 0) > now(): continue
        if not fresh(t): continue
        if (not t['g_t'] or now() - t['g_t'] > 600) and not (t.get('pp_t') and c['fn'] is s_sniper): continue
        sc, why = c['fn'](t)
        if sc <= 0: continue
        rf = red_flags(t)
        if rf: continue
        if best is None or sc > best[0]: best = (sc, t, why)
    STATS['evals'] += 1
    if best: buy(b, c, best[1], best[0], best[2])
    else: b['last_reason'] = 'scan…'

# ---------------------------------------------------------------- persistence / snapshot
HIST = {}   # bot -> list[[t, eq]]
_LAST_BAK = [0]
def save_state():
    tmp = P('state.json.tmp')
    with open(tmp, 'w') as f:
        json.dump({'state': STATE, 'hist': HIST}, f)
        f.flush(); os.fsync(f.fileno())
    os.replace(tmp, P('state.json'))
    if now() - _LAST_BAK[0] > 600:                 # copie de secours toutes les 10 min
        _LAST_BAK[0] = now()
        try:
            import shutil; shutil.copyfile(P('state.json'), P('state.json.bak.tmp')); os.replace(P('state.json.bak.tmp'), P('state.json.bak'))
        except Exception: pass

def _read_state_file():
    for f in ('state.json', 'state.json.bak'):
        try:
            d = json.load(open(P(f)))
            if isinstance(d, dict) and isinstance(d.get('state'), dict) and d['state'].get('bots'):
                if f != 'state.json': print('state.json illisible : reprise depuis la copie de secours', flush=True)
                return d
        except FileNotFoundError: continue
        except Exception:
            print('fichier %s corrompu, ignoré' % f, flush=True)
            try: os.replace(P(f), P(f + '.corrupt.%d' % now()))
            except Exception: pass
    return None

DATA_FILES = ('state.json', 'state.json.bak', 'history.json', 'snapshot.json', 'trades.jsonl', 'events.jsonl')
def reset_300_v1():
    """Migration unique : archive l'ancienne course (5 x 10 EUR) dans data/archive_<date>/ et repart à 5 x 60 EUR."""
    d = _read_state_file()
    if d and d['state'].get(RESET_FLAG): return False
    present = [f for f in DATA_FILES if os.path.exists(P(f))]
    if present:
        arch = P('archive_' + paris().strftime('%Y%m%d_%H%M%S'))
        os.makedirs(arch, exist_ok=True)
        for f in present:
            try: os.replace(P(f), os.path.join(arch, f))
            except Exception: traceback.print_exc()
        print('ancienne course archivée dans', arch, flush=True)
    return True

def load_state():
    d = _read_state_file()
    if not d: return False
    if True:  # noqa
        STATE.update(d['state']); HIST.update(d.get('hist', {}))
        fix_mace_v1()
        for b in STATE['bots'].values():
            for p in b['pos']:
                t = tok(p['mint']); t['sym'] = p.get('sym') or t['sym']; t['dex'] = p.get('dex') or t['dex']
                if p.get('pool'): t['pool'] = p['pool']
                last = fnum(p.get('last_px'))
                if last > 0: t['px_sol'] = last
        return True

def _trade_voidable_mace(r):
    if r.get('void'): return False
    mint = r.get('mint') or ''
    if mint != MACE_MINT: return False
    bot = r.get('bot') or ''
    side = (r.get('side') or '').upper()
    tid = r.get('id')
    if tid in (65, 66): return True  # TP fictifs Le Sélectionneur
    if bot == 'Le Sélectionneur' and side in ('TP', 'SELL'): return True
    return False

def _rewrite_trades_jsonl(void_ids, void_reason):
    path = P('trades.jsonl')
    try:
        raw = open(path, encoding='utf-8').read().splitlines()
    except FileNotFoundError:
        return
    out, changed = [], False
    for line in raw:
        if not line.strip():
            continue
        try:
            r = json.loads(line)
        except Exception:
            out.append(line); continue
        if r.get('id') in void_ids or _trade_voidable_mace(r):
            if not r.get('void'):
                r['void'] = True
                r['void_reason'] = void_reason
                changed = True
        out.append(json.dumps(r, ensure_ascii=False))
    if changed:
        tmp = path + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as f:
            f.write('\n'.join(out) + ('\n' if out else ''))
        os.replace(tmp, path)

def _repair_hist(first_epoch, bot_names):
    """Retire de l'historique les points gonflés par le faux prix MACE."""
    if not first_epoch: return
    eqs = {}
    for n in bot_names:
        if n == 'TOTAL':
            eqs[n] = sum(bot_equity(b) for b in STATE['bots'].values())
        elif n in STATE['bots']:
            eqs[n] = bot_equity(STATE['bots'][n])
    for n, eq in eqs.items():
        h = HIST.get(n) or []
        if not h: continue
        kept = []
        for pt in h:
            t, v = pt[0], pt[1]
            if t >= first_epoch - 1 and v > eq + 8 and v > 20:
                continue
            kept.append(pt)
        if not kept or kept[-1][1] != round(eq, 4):
            kept.append([round(now()), round(eq, 4)])
        HIST[n] = kept

def _recompute_best_worst(b):
    best = worst = None
    for r in STATE.get('trades') or []:
        if r.get('void') or r.get('bot') != b.get('name'): continue
        if (r.get('side') or '').upper() not in ('SELL',): continue
        pnl = r.get('pnl_eur')
        # coût approximatif : on n'a que pnl/eur
        if pnl is None: continue
        eur = fnum(r.get('eur'))
        cost = eur - fnum(pnl)
        pct = (fnum(pnl) / cost * 100) if cost > 0 else 0.0
        rec = {'sym': r.get('sym') or '?', 'pct': round(pct, 1)}
        if best is None or rec['pct'] > best['pct']: best = rec
        if worst is None or rec['pct'] < worst['pct']: worst = rec
    b['best'], b['worst'] = best, worst

def _close_pos_at_cost(b, p, reason):
    """Ferme une position au prix d'entrée : pnl 0, cash remboursé = coût d'origine (frais déjà comptés à l'achat)."""
    cost = fnum(p.get('cost_eur'))
    b['cash'] = fnum(b.get('cash')) + cost
    # la part déjà réalisée sur cette position (faux TP) a déjà été retirée avant l'appel
    if p in b['pos']:
        b['pos'].remove(p)
    t = tok(p.get('mint') or '')
    t['sym'] = p.get('sym') or t.get('sym') or '?'
    t['dex'] = p.get('dex') or t.get('dex') or ''
    # trade de correction visible, pnl 0, sans toucher wins/losses/trades
    STATE['seq'] = int(STATE.get('seq') or 0) + 1
    rec = {'id': STATE['seq'], 'ts': ts(), 'epoch': round(now(), 1), 'bot': b['name'], 'side': 'SELL',
           'sym': p.get('sym') or t.get('sym') or '?', 'mint': p.get('mint'), 'dex': p.get('dex') or '',
           'px_sol': fnum(p.get('entry_px')), 'eur': round(cost, 4), 'pnl_eur': 0.0, 'reason': reason,
           'correction': True}
    STATE['trades'].append(rec)
    del STATE['trades'][:-400]
    try:
        with open(P('trades.jsonl'), 'a') as f: f.write(json.dumps(rec, ensure_ascii=False) + '\n')
    except Exception: pass
    log_ev('fix', 'correction %s : position fermée au coût (pnl 0, +%.2f€ cash) · %s' % (p.get('sym') or '?', cost, reason), b['name'], mint=p.get('mint'))

def fix_mace_v1():
    """Migration unique : annule les faux gains MACE (mauvais pool / saut de prix x150) et
    ferme les positions MACE de Le Sélectionneur et Le Surfeur au coût (pnl 0)."""
    if STATE.get('fix_mace_v1'):
        return False
    void_reason = 'prix erroné (mauvais pool / saut irréaliste) — trade annulé'
    trades = list(STATE.get('trades') or [])
    void_ids = set()
    first_epoch = None
    # 1) Annuler les TP/ventes fictifs de Le Sélectionneur sur MACE
    for r in trades:
        if not _trade_voidable_mace(r):
            continue
        r['void'] = True
        r['void_reason'] = void_reason
        void_ids.add(r.get('id'))
        bot = STATE['bots'].get(r.get('bot') or '')
        if not bot: continue
        proceeds = fnum(r.get('eur'))
        pnl = fnum(r.get('pnl_eur'))
        bot['cash'] = fnum(bot.get('cash')) - proceeds
        bot['realized'] = fnum(bot.get('realized')) - pnl
        if (r.get('side') or '').upper() == 'SELL':
            # clôture complète déjà comptée : on retire le trade des compteurs
            if fnum(r.get('pnl_eur')) >= 0 and int(bot.get('wins') or 0) > 0:
                bot['wins'] = int(bot['wins']) - 1
            elif fnum(r.get('pnl_eur')) < 0 and int(bot.get('losses') or 0) > 0:
                bot['losses'] = int(bot['losses']) - 1
            if int(bot.get('trades') or 0) > 0:
                bot['trades'] = int(bot['trades']) - 1
        ep = fnum(r.get('epoch')) or 0
        if ep and (first_epoch is None or ep < first_epoch):
            first_epoch = ep
    # 2) Retirer le realized déjà inscrit sur la position MACE, puis fermer au coût
    closed_any = False
    for name in MACE_BOTS_CLOSE:
        b = STATE['bots'].get(name)
        if not b: continue
        for p in list(b.get('pos') or []):
            if (p.get('mint') or '') != MACE_MINT and (p.get('sym') or '').upper() != 'MACE':
                continue
            # si des TP ont déjà été retirés du cash, p['realized'] contient encore ces pnl
            already = fnum(p.get('realized'))
            # already normally already subtracted from bot.realized via the trades loop;
            # don't subtract twice. Just zero the position realized.
            p['realized'] = 0.0
            p['tp_done'] = []
            p['qty'] = p.get('qty0') or p.get('qty')
            if not first_epoch:
                first_epoch = fnum(p.get('opened')) or now()
            _close_pos_at_cost(b, p, 'correction prix erroné MACE (fermée au coût)')
            closed_any = True
            _recompute_best_worst(b)
            b.setdefault('bans', {})[MACE_MINT] = now() + 6 * 3600
    # Si les ventes MACE ont été annulées mais que la position était déjà clôturée : rembourser le coût d'achat
    for name in MACE_BOTS_CLOSE:
        b = STATE['bots'].get(name)
        if not b: continue
        still = any((p.get('mint') == MACE_MINT or (p.get('sym') or '').upper() == 'MACE') for p in b.get('pos') or [])
        if still: continue
        had_void_sell = any((r.get('id') in void_ids and r.get('bot') == name) for r in STATE.get('trades') or [])
        already_refunded = any(r.get('correction') and r.get('bot') == name and r.get('mint') == MACE_MINT for r in STATE.get('trades') or [])
        if had_void_sell and not already_refunded:
            buy_tr = next((r for r in STATE.get('trades') or [] if r.get('bot') == name and r.get('mint') == MACE_MINT and (r.get('side') or '').upper() == 'BUY'), None)
            if buy_tr:
                fake_p = {'mint': MACE_MINT, 'sym': buy_tr.get('sym') or 'MACE', 'dex': buy_tr.get('dex') or '',
                          'cost_eur': fnum(buy_tr.get('eur')), 'entry_px': fnum(buy_tr.get('px_sol')), 'qty': 0, 'qty0': 0}
                _close_pos_at_cost(b, fake_p, 'correction prix erroné MACE (fermée au coût)')
                closed_any = True
                _recompute_best_worst(b)
                b.setdefault('bans', {})[MACE_MINT] = now() + 6 * 3600
    _rewrite_trades_jsonl(void_ids, void_reason)
    if first_epoch or closed_any or void_ids:
        _repair_hist(first_epoch or now(), list(MACE_BOTS_CLOSE) + ['TOTAL'])
        log_ev('fix', 'migration fix_mace_v1 : faux gains MACE annulés, positions fermées au coût')
    STATE['fix_mace_v1'] = True
    try:
        save_state()
    except Exception:
        traceback.print_exc()
    return True

def add_hist(n, eq):
    h = HIST.setdefault(n, [])
    t = round(now())
    if h and t - h[-1][0] < 30: h[-1] = [h[-1][0], round(eq, 4)]
    else: h.append([t, round(eq, 4)])
    if len(h) > 6000:   # au-delà : on compresse les vieux points (1 sur 2)
        HIST[n] = h[:-3000:2] + h[-3000:]

def snapshot():
    bots = []
    tot = 0.0
    for c in BOTS_CFG:
        b = STATE['bots'][c['name']]; eq = bot_equity(b); tot += eq
        pos = []
        for p in b['pos']:
            v, px = pos_value_eur(p)
            t = TOK.get(p['mint']) or {}
            pos.append({'sym': p['sym'], 'mint': p['mint'], 'dex': p['dex'], 'cost_eur': round(p['cost_eur'] * p['qty'] / p['qty0'], 3), 'value_eur': round(v, 3),
                        'gain_pct': round((px / p['entry_px'] - 1) * 100, 2), 'peak_pct': round((p['peak'] / p['entry_px'] - 1) * 100, 1),
                        'left_pct': round(p['qty'] / p['qty0'] * 100), 'tp_done': len(p['tp_done']), 'age_s': round(now() - p['opened']),
                        'mcap': round(t.get('mcap', 0)), 'px_age_s': round(now() - t.get('px_t', 0)) if t.get('px_t') else None, 'why': p['why']})
        n = b['wins'] + b['losses']
        bots.append({'name': c['name'], 'emoji': c['emoji'], 'col': c['col'], 'blurb': c['blurb'], 'equity_eur': round(eq, 4), 'cash_eur': round(b['cash'], 4),
                     'start_eur': b['start_eur'], 'pnl_eur': round(eq - b['start_eur'], 4), 'pnl_pct': round((eq / b['start_eur'] - 1) * 100, 2),
                     'realized_eur': round(b['realized'], 4), 'fees_eur': round(b['fees'], 4), 'trades': b['trades'], 'wins': b['wins'], 'losses': b['losses'],
                     'win_rate': round(b['wins'] / n * 100, 1) if n else None, 'positions': pos, 'status': b['last_reason'], 'best': b['best'], 'worst': b['worst'],
                     'rules': {'size_pct': round(c['size'] * 100), 'maxpos': c['maxpos'], 'sl_pct': round(c['sl'] * 100), 'tp': [[round(l * 100), round(f * 100)] for l, f in c['tp']],
                               'trail_arm_pct': round(c['arm'] * 100), 'trail_pct': round(c['trail'] * 100), 'tmax_min': c['tmax'] / 60, 'cooldown_s': c['cool']}})
    st = STATE['start']
    snap = {'mode': 'SIMULATION', 'version': CODE_VERSION, 'migrations': [k for k in ('fix_mace_v1', RESET_FLAG) if STATE.get(k)],
            'updated': ts(), 'epoch': round(now(), 1), 'start': st, 'start_ts': ts(st) if st else None,
            'end_test_ts': ts(TEST_END_TS), 'total_eur': round(tot, 4),
            'start_total_eur': round(sum(STATE['bots'][c['name']]['start_eur'] for c in BOTS_CFG), 2),
            'start_per_bot_eur': START_EUR,
            'night_pause': night_pause(), 'night_rule': 'Pause nuit : aucune nouvelle entrée de 01h00 à 08h00 (heure de Paris), positions ouvertes toujours gérées',
            'sol_eur': FX['sol_eur'], 'sources': dict(SRC), 'stats': dict(STATS), 'bots': bots,
            'trades': [t for t in STATE['trades'] if not t.get('void')][-80:][::-1], 'events': list(EVENTS)[-60:][::-1]}
    return snap

def write_json(name, obj):
    tmp = P(name + '.tmp')
    with open(tmp, 'w') as f: json.dump(obj, f, ensure_ascii=False, separators=(',', ':'))
    os.replace(tmp, P(name))

def hist_export():
    out = {}
    for n, h in HIST.items():
        # dernières 2h à 30 s + le reste à ~5 min
        cut = now() - 7200; recent = [x for x in h if x[0] >= cut]; old = [x for x in h if x[0] < cut]
        step = max(1, len(old) // 1500) if old else 1
        out[n] = old[::step] + recent
    return out

# ---------------------------------------------------------------- main
def main():
    did_reset = reset_300_v1()
    if not load_state():
        STATE['start'] = round(now()); STATE['bots'] = {c['name']: new_bot(c['name']) for c in BOTS_CFG}
        STATE[RESET_FLAG] = True; STATE['fix_mace_v1'] = True
        log_ev('start', 'Départ de la simulation : 5 bots × %.0f € fictifs = %.0f €. Test jusqu’au 1er janvier 2027.%s'
               % (START_EUR, START_EUR * len(BOTS_CFG), ' (ancienne course 5 × 10 € archivée)' if did_reset else ''))
        save_state()
    for c in BOTS_CFG: STATE['bots'].setdefault(c['name'], new_bot(c['name']))
    log_ev('resume', 'Moteur démarré (SIMULATION, aucune transaction réelle)')
    SRC['pumpportal'] = 'init'
    for fn in (fx_loop, gecko_loop, dex_loop, pp_loop): threading.Thread(target=fn, daemon=True).start()
    last_save = last_hist = last_hexp = 0; was_night = None
    while True:
        try:
            with LOCK:
                nightp = night_pause()
                if nightp != was_night and was_night is not None:
                    log_ev('night', '🌙 Pause nuit : plus de nouvelles entrées jusqu’à 08h00' if nightp else '☀️ Fin de la pause nuit : les bots peuvent de nouveau entrer')
                was_night = nightp
                if FX['sol_eur'] > 0:
                    for c in BOTS_CFG:
                        b = STATE['bots'][c['name']]
                        manage(b, c); scan(b, c)
                    write_json('snapshot.json', snapshot())
                    if now() - last_hist >= 30:
                        last_hist = now()
                        for c in BOTS_CFG: add_hist(c['name'], bot_equity(STATE['bots'][c['name']]))
                        add_hist('TOTAL', sum(bot_equity(STATE['bots'][c['name']]) for c in BOTS_CFG))
                    if now() - last_hexp >= 30:
                        last_hexp = now(); write_json('history.json', hist_export())
                    if now() - last_save >= 5:
                        last_save = now(); save_state()
        except Exception:
            traceback.print_exc()
        time.sleep(1.0)

if __name__ == '__main__':
    main()
