#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Grok Bot · Arène SIMULATION — 5 bots Pump.fun indépendants, 10 EUR fictifs chacun (50 EUR au total).
100% PAPER TRADING : aucune clé privée, aucune signature, aucune transaction. Données de marché réelles :
  - GeckoTerminal (découverte : pools pump.fun bonding-curve + PumpSwap, acheteurs/vendeurs uniques, variations)
  - DexScreener  (prix temps réel des positions et candidats, liquidité, txns m5/h1)
  - Binance      (SOL/EUR, SOL/USDT)
Frais/slippage simulés de façon réaliste (frais pump.fun / PumpSwap, frais réseau, impact de prix, latence).
Pause nuit : aucune NOUVELLE entrée entre 01:00 et 08:00 (Europe/Paris) ; les positions ouvertes restent gérées.
"""
import json, os, time, threading, urllib.request, urllib.error, traceback, math, random, sys
from collections import deque
from datetime import datetime
try:
    from zoneinfo import ZoneInfo
    TZ = ZoneInfo('Europe/Paris')
except Exception:
    TZ = None

if os.environ.get('PUMPBOTS_LIVE', '0') not in ('', '0'):
    sys.exit('Ce programme est SIMULATION uniquement (PUMPBOTS_LIVE doit valoir 0).')

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.environ.get('SIM_DATA', os.path.join(HERE, 'data'))
os.makedirs(DATA, exist_ok=True)
P = lambda f: os.path.join(DATA, f)
UA = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) simbot/1.0', 'Accept': 'application/json'}
WSOL = 'So11111111111111111111111111111111111111112'
START_EUR = 10.0
NIGHT = (1, 8)  # pas de nouvelles entrées de 01:00 à 08:00 heure de Paris

def now(): return time.time()
def paris(t=None):
    t = t or now()
    return datetime.fromtimestamp(t, TZ) if TZ else datetime.fromtimestamp(t)
def ts(t=None): return paris(t).strftime('%Y-%m-%d %H:%M:%S')
def night_pause(t=None):
    h = paris(t).hour
    return NIGHT[0] <= h < NIGHT[1]
def fnum(x, d=0.0):
    try:
        if x is None: return d
        v = float(x)
        return v if math.isfinite(v) else d
    except Exception: return d
def http_json(url, t=10):
    r = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(r, timeout=t) as f: return json.loads(f.read(4_000_000))

LOCK = threading.RLock()
SRC = {'geckoterminal': 'init', 'dexscreener': 'init', 'binance': 'init'}
STATS = {'gecko_calls': 0, 'gecko_err': 0, 'dex_calls': 0, 'dex_err': 0, 'tokens': 0, 'evals': 0}
FX = {'sol_eur': 0.0, 'sol_usd': 0.0}
TOK = {}           # mint -> token data
EVENTS = deque(maxlen=200)

def log_ev(kind, msg, bot=None, **kw):
    e = {'ts': ts(), 'epoch': round(now(), 1), 'type': kind, 'msg': msg}
    if bot: e['bot'] = bot
    e.update(kw)
    with LOCK: EVENTS.append(e)
    try:
        with open(P('events.jsonl'), 'a') as f: f.write(json.dumps(e, ensure_ascii=False) + '\n')
    except Exception: pass
    print(e['ts'], kind, bot or '', msg, flush=True)

# ---------------------------------------------------------------- market data
def tok(mint):
    t = TOK.get(mint)
    if t is None:
        t = TOK[mint] = {'mint': mint, 'sym': '?', 'name': '', 'dex': '', 'pool': '', 'created': 0, 'px_sol': 0.0, 'px_usd': 0.0,
                         'mcap': 0.0, 'liq': 0.0, 'liq_sol': 0.0, 'ch': {}, 'tx': {}, 'vol': {}, 'g_t': 0, 'd_t': 0, 'px_t': 0,
                         'hist': deque(maxlen=400), 'max10': deque(maxlen=200), 'seen': now(), 'migrated_at': 0}
    return t

def set_px(t, px_sol, px_usd, src):
    if px_sol <= 0 and px_usd > 0 and FX['sol_usd'] > 0: px_sol = px_usd / FX['sol_usd']
    if px_sol <= 0: return
    t['px_sol'] = px_sol; t['px_usd'] = px_usd or px_sol * FX['sol_usd']; t['px_t'] = now()
    t['hist'].append((now(), px_sol))

def parse_gecko_pool(p, inc):
    a = p.get('attributes', {}); rel = p.get('relationships', {})
    dex = ((rel.get('dex') or {}).get('data') or {}).get('id', '')
    if dex not in ('pump-fun', 'pumpswap'): return
    q = ((rel.get('quote_token') or {}).get('data') or {}).get('id', '')
    if q and q != 'solana_' + WSOL: return
    b = ((rel.get('base_token') or {}).get('data') or {}).get('id', '')
    if not b.startswith('solana_'): return
    mint = b[7:]
    if mint == WSOL: return
    with LOCK:
        t = tok(mint)
        if dex == 'pumpswap' and t['dex'] == 'pump-fun': t['migrated_at'] = now()
        if dex == 'pump-fun' and t['dex'] == 'pumpswap': return  # garder le pool PumpSwap une fois migré
        t['dex'] = dex; t['pool'] = a.get('address', t['pool'])
        nm = (a.get('name') or '').split(' / ')[0]
        if nm: t['sym'] = nm[:16]
        inf = inc.get(b)
        if inf: t['sym'] = (inf.get('symbol') or t['sym'])[:16]; t['name'] = inf.get('name') or ''
        try: t['created'] = datetime.fromisoformat(a['pool_created_at'].replace('Z', '+00:00')).timestamp()
        except Exception: pass
        if dex == 'pumpswap' and not t['migrated_at']: t['migrated_at'] = t['created']
        t['ch'] = {k: fnum(v) for k, v in (a.get('price_change_percentage') or {}).items()}
        t['tx'] = {k: {'b': int(fnum(v.get('buys'))), 's': int(fnum(v.get('sells'))), 'bu': int(fnum(v.get('buyers'))), 'se': int(fnum(v.get('sellers')))}
                   for k, v in (a.get('transactions') or {}).items()}
        t['vol'] = {k: fnum(v) for k, v in (a.get('volume_usd') or {}).items()}
        t['mcap'] = fnum(a.get('market_cap_usd')) or fnum(a.get('fdv_usd'))
        r = fnum(a.get('reserve_in_usd'))
        if r: t['liq'] = r
        t['g_t'] = now()
        if now() - t['px_t'] > 20:
            set_px(t, fnum(a.get('base_token_price_native_currency')), fnum(a.get('base_token_price_usd')), 'gecko')

GECKO_ROT = [
    'networks/solana/new_pools?page=1&include=base_token,dex,quote_token',
    'networks/solana/dexes/pump-fun/pools?page=1&sort=h24_tx_count_desc&include=base_token,dex,quote_token',
    'networks/solana/dexes/pumpswap/pools?page=1&sort=h24_volume_usd_desc&include=base_token,dex,quote_token',
    'networks/solana/trending_pools?page=1&duration=5m&include=base_token,dex,quote_token',
    'networks/solana/new_pools?page=2&include=base_token,dex,quote_token',
    'networks/solana/dexes/pumpswap/pools?page=2&sort=h24_volume_usd_desc&include=base_token,dex,quote_token',
    'networks/solana/trending_pools?page=1&duration=1h&include=base_token,dex,quote_token',
    'networks/solana/dexes/pump-fun/pools?page=2&sort=h24_tx_count_desc&include=base_token,dex,quote_token',
    'networks/solana/new_pools?page=1&include=base_token,dex,quote_token',
    'networks/solana/dexes/pumpswap/pools?page=1&sort=h24_tx_count_desc&include=base_token,dex,quote_token',
    'networks/solana/trending_pools?page=2&duration=5m&include=base_token,dex,quote_token',
    'networks/solana/dexes/pumpswap/pools?page=3&sort=h24_volume_usd_desc&include=base_token,dex,quote_token',
    'networks/solana/trending_pools?page=1&duration=6h&include=base_token,dex,quote_token',
    'networks/solana/dexes/pump-fun/pools?page=1&sort=h24_volume_usd_desc&include=base_token,dex,quote_token',
]
def gecko_loop():
    i = 0; back = 3.2
    while True:
        u = 'https://api.geckoterminal.com/api/v2/' + GECKO_ROT[i % len(GECKO_ROT)]; i += 1
        try:
            d = http_json(u, 12); STATS['gecko_calls'] += 1
            inc = {x['id']: x.get('attributes', {}) for x in d.get('included', []) if x.get('type') == 'token'}
            for p in d.get('data', []): parse_gecko_pool(p, inc)
            SRC['geckoterminal'] = 'ok'; back = 3.2
        except urllib.error.HTTPError as e:
            STATS['gecko_err'] += 1; SRC['geckoterminal'] = f'HTTP {e.code}'
            if e.code == 429: back = min(30, back * 2)
        except Exception as e:
            STATS['gecko_err'] += 1; SRC['geckoterminal'] = 'erreur ' + str(e)[:60]
        # nettoyage
        with LOCK:
            cut = now() - 3 * 3600
            held = held_mints()
            for m in [m for m, t in TOK.items() if max(t['g_t'], t['d_t']) < cut and m not in held]: TOK.pop(m, None)
            STATS['tokens'] = len(TOK)
        time.sleep(back)

def dex_apply(pairs):
    best = {}
    for p in pairs or []:
        if p.get('chainId') != 'solana': continue
        if (p.get('quoteToken') or {}).get('address') != WSOL: continue
        if p.get('dexId') not in ('pumpfun', 'pumpswap'): continue
        m = (p.get('baseToken') or {}).get('address')
        if not m: continue
        lq = fnum((p.get('liquidity') or {}).get('usd'))
        if m not in best or (p.get('dexId') == 'pumpswap' and best[m].get('dexId') != 'pumpswap') or lq > fnum((best[m].get('liquidity') or {}).get('usd')):
            best[m] = p
    with LOCK:
        for m, p in best.items():
            t = tok(m)
            t['sym'] = ((p.get('baseToken') or {}).get('symbol') or t['sym'])[:16]
            dx = 'pumpswap' if p.get('dexId') == 'pumpswap' else 'pump-fun'
            if dx == 'pumpswap' and t['dex'] == 'pump-fun': t['migrated_at'] = now()
            t['dex'] = dx
            l = p.get('liquidity') or {}
            if fnum(l.get('usd')): t['liq'] = fnum(l.get('usd'))
            if fnum(l.get('quote')): t['liq_sol'] = fnum(l.get('quote'))
            t['mcap'] = fnum(p.get('marketCap')) or fnum(p.get('fdv')) or t['mcap']
            t['dtx'] = {k: {'b': int(fnum(v.get('buys'))), 's': int(fnum(v.get('sells')))} for k, v in (p.get('txns') or {}).items()}
            t['dch'] = {k: fnum(v) for k, v in (p.get('priceChange') or {}).items()}
            if not t['created'] and p.get('pairCreatedAt'): t['created'] = fnum(p['pairCreatedAt']) / 1000
            t['d_t'] = now()
            set_px(t, fnum(p.get('priceNative')), fnum(p.get('priceUsd')), 'dex')

def dex_loop():
    while True:
        try:
            with LOCK:
                held = list(held_mints())
                cands = sorted([t for t in TOK.values() if t['mint'] not in held and pre_ok(t)], key=lambda t: -t['g_t'])
                want = held + [t['mint'] for t in cands if now() - t['d_t'] > 4][:max(0, 60 - len(held))]
            for k in range(0, min(len(want), 90), 30):
                chunk = want[k:k + 30]
                try:
                    d = http_json('https://api.dexscreener.com/tokens/v1/solana/' + ','.join(chunk), 10); STATS['dex_calls'] += 1
                    dex_apply(d if isinstance(d, list) else d.get('pairs'))
                    SRC['dexscreener'] = 'ok'
                except Exception as e:
                    STATS['dex_err'] += 1; SRC['dexscreener'] = 'erreur ' + str(e)[:60]
                time.sleep(0.4)
        except Exception: traceback.print_exc()
        time.sleep(2.0)

def fx_loop():
    while True:
        try:
            e = http_json('https://data-api.binance.vision/api/v3/ticker/price?symbol=SOLEUR', 8)
            u = http_json('https://data-api.binance.vision/api/v3/ticker/price?symbol=SOLUSDT', 8)
            FX['sol_eur'] = fnum(e['price']); FX['sol_usd'] = fnum(u['price']); SRC['binance'] = 'ok'
        except Exception as ex:
            SRC['binance'] = 'erreur ' + str(ex)[:50]
        time.sleep(10)

# ---------------------------------------------------------------- helpers on token stats
def age_min(t): return (now() - t['created']) / 60 if t['created'] else -1
def txw(t, w): return t['tx'].get(w) or {'b': 0, 's': 0, 'bu': 0, 'se': 0}
def ratio(a, b): return a / b if b > 0 else (9.9 if a > 0 else 0)
def micro_ok(t, secs=40, tol=0.03):
    """pas de chute dans les dernières secondes (prix actuel >= max récent * (1-tol))"""
    h = [p for (tt, p) in t['hist'] if now() - tt <= secs]
    if len(h) < 2: return True
    return h[-1] >= max(h) * (1 - tol)
def rugged(t):
    h = [p for (tt, p) in t['hist'] if now() - tt <= 900]
    return len(h) >= 2 and h[-1] < max(h) * 0.45
def fresh(t, s=12): return now() - t['px_t'] <= s and t['px_sol'] > 0 and now() - t['d_t'] <= s
def pre_ok(t):
    """pré-filtre large : vaut-il la peine de rafraîchir ce token sur DexScreener ?"""
    if not t['g_t'] or now() - t['g_t'] > 900: return False
    tx5 = txw(t, 'm5'); tx1 = txw(t, 'h1')
    return (tx5['bu'] >= 8 or tx1['bu'] >= 60) and t['mcap'] >= 6000

# ---------------------------------------------------------------- strategies
def red_flags(t):
    if rugged(t): return 'chute >55% en 15 min (rug?)'
    d5 = (t.get('dtx') or {}).get('m5') or {'b': 0, 's': 0}
    if d5['s'] > 3 * max(1, d5['b']) and d5['s'] > 15: return 'ventes massives m5'
    if t['dex'] == 'pumpswap' and t['mcap'] > 0 and t['liq'] / t['mcap'] < 0.04: return 'liquidité trop faible vs mcap'
    if t['sym'] in ('?', '') : return 'symbole inconnu'
    return ''

def s_quality(t):
    a = age_min(t); m5 = txw(t, 'm5'); h1 = txw(t, 'h1'); ch = t['ch']
    if not (20 <= a <= 24 * 60): return 0, 'âge'
    if not (40e3 <= t['mcap'] <= 5e6): return 0, 'mcap'
    if t['liq'] < 15e3: return 0, 'liquidité'
    if t['vol'].get('h1', 0) < 25e3: return 0, 'volume h1'
    if h1['bu'] < 60 or ratio(h1['bu'], h1['se']) < 1.15: return 0, 'acheteurs h1'
    if m5['bu'] < 8 or m5['bu'] < m5['se']: return 0, 'acheteurs m5'
    if not (0 < ch.get('m5', 0) <= 15): return 0, 'm5'
    if not (5 <= ch.get('h1', 0) <= 120) or ch.get('m30', 0) <= 0: return 0, 'tendance h1/m30'
    if not micro_ok(t): return 0, 'micro-chute'
    return 50 + min(30, h1['bu'] / 10) + 10 * min(2, ratio(h1['bu'], h1['se'])) + min(10, t['liq'] / 1e4), 'qualité: %d acheteurs/h, x%.2f ach/vend, liq %.0fk$' % (h1['bu'], ratio(h1['bu'], h1['se']), t['liq'] / 1e3)

def s_migration(t):
    if t['dex'] != 'pumpswap': return 0, 'pas migré'
    mig = t['migrated_at'] or t['created']
    am = (now() - mig) / 60 if mig else -1
    if not (3 <= am <= 90): return 0, 'âge migration'
    m15 = txw(t, 'm15'); h1 = txw(t, 'h1'); ch = t['ch']
    if t['liq'] < 12e3 or not (50e3 <= t['mcap'] <= 2e6): return 0, 'liq/mcap'
    if h1['bu'] < 50 or ratio(m15['bu'], m15['se']) < 1.1: return 0, 'acheteurs'
    if ch.get('m5', 0) <= 0 or ch.get('m15', 0) < -10 or ch.get('h1', 0) > 200: return 0, 'momentum'
    if not micro_ok(t): return 0, 'micro-chute'
    return 55 + min(30, h1['bu'] / 8) + 10 * min(2, ratio(m15['bu'], m15['se'])), 'migré il y a %d min, %d acheteurs/h' % (am, h1['bu'])

def s_sniper(t):
    if t['dex'] != 'pump-fun': return 0, 'pas sur la courbe'
    a = age_min(t); m5 = txw(t, 'm5'); ch = t['ch']
    if not (2 <= a <= 15): return 0, 'âge'
    if not (7e3 <= t['mcap'] <= 40e3): return 0, 'mcap'
    if m5['bu'] < 25 or ratio(m5['bu'], m5['se']) < 1.6: return 0, 'acheteurs m5'
    if t['vol'].get('m5', 0) < 3e3: return 0, 'volume m5'
    if not (5 <= ch.get('m5', 0) <= 80): return 0, 'm5'
    if not micro_ok(t, 30, 0.04): return 0, 'micro-chute'
    return 50 + min(30, m5['bu'] / 3) + 10 * min(2, ratio(m5['bu'], m5['se'])), 'jeune %.0f min, %d acheteurs/5min x%.1f' % (a, m5['bu'], ratio(m5['bu'], m5['se']))

def s_dip(t):
    a = age_min(t); m5 = txw(t, 'm5'); ch = t['ch']
    if a < 360: return 0, 'âge'
    if t['liq'] < 30e3 or not (150e3 <= t['mcap'] <= 30e6): return 0, 'liq/mcap'
    if t['vol'].get('h24', 0) < 150e3: return 0, 'volume 24h'
    if ch.get('h24', 0) < 15 and ch.get('h6', 0) < 10: return 0, 'pas de tendance de fond'
    if not (-45 <= ch.get('h1', 0) <= -12): return 0, 'pas de creux h1'
    if ch.get('m5', 0) < 1.5 or m5['bu'] <= m5['se']: return 0, 'pas de rebond'
    if not micro_ok(t, 40, 0.02): return 0, 'micro-chute'
    return 50 + min(25, -ch['h1']) + min(15, t['liq'] / 2e4), 'creux %.0f%% h1 sur tendance +%.0f%% 24h, rebond m5' % (ch['h1'], ch.get('h24', 0))

def s_trend(t):
    a = age_min(t); h1 = txw(t, 'h1'); ch = t['ch']
    if a < 120: return 0, 'âge'
    if not (300e3 <= t['mcap'] <= 50e6) or t['liq'] < 50e3: return 0, 'liq/mcap'
    if not (8 <= ch.get('h1', 0) <= 70) or ch.get('h6', 0) <= 10 or ch.get('m15', 0) <= 0: return 0, 'tendance'
    if not (0 <= ch.get('m5', 0) <= 10): return 0, 'm5 (pas de poursuite de pic)'
    if h1['bu'] < 150 or ratio(h1['bu'], h1['se']) < 1.1 or t['vol'].get('h1', 0) < 50e3: return 0, 'flux acheteurs'
    if not micro_ok(t, 40, 0.02): return 0, 'micro-chute'
    return 50 + min(25, ch['h1'] / 2) + min(20, h1['bu'] / 30), 'breakout +%.0f%% h1 / +%.0f%% 6h, %d acheteurs/h' % (ch['h1'], ch['h6'], h1['bu'])

BOTS_CFG = [
    {'name': 'Le Sélectionneur', 'emoji': '💎', 'col': '#22e4ff', 'fn': s_quality,
     'blurb': 'Ne prend que les meilleurs coins : beaucoup de vrais acheteurs, volume, liquidité, tendance saine.',
     'size': 0.22, 'maxpos': 2, 'sl': -0.14, 'tp': [(0.25, 0.50), (0.60, 0.25)], 'arm': 0.25, 'trail': 0.12, 'tmax': 7200, 'tmin': 0.05, 'cool': 180},
    {'name': 'Le Diplômé', 'emoji': '🎓', 'col': '#b44dff', 'fn': s_migration,
     'blurb': 'Coins qui viennent de terminer la bonding curve et de migrer sur PumpSwap, avec flux acheteur.',
     'size': 0.20, 'maxpos': 2, 'sl': -0.16, 'tp': [(0.35, 0.50), (0.80, 0.25)], 'arm': 0.35, 'trail': 0.15, 'tmax': 5400, 'tmin': 0.05, 'cool': 180},
    {'name': 'Le Sniper', 'emoji': '🎯', 'col': '#ff4fd8', 'fn': s_sniper,
     'blurb': 'Coins très jeunes (2-15 min) sur la courbe, filtres stricts, petites mises.',
     'size': 0.08, 'maxpos': 3, 'sl': -0.20, 'tp': [(0.50, 0.50), (1.20, 0.30)], 'arm': 0.50, 'trail': 0.20, 'tmax': 1200, 'tmin': 0.10, 'cool': 120},
    {'name': 'Le Chasseur de Creux', 'emoji': '🪝', 'col': '#39ff88', 'fn': s_dip,
     'blurb': 'Achète les creux (-12 à -45 % sur 1h) de coins établis en tendance haussière, au rebond.',
     'size': 0.20, 'maxpos': 2, 'sl': -0.10, 'tp': [(0.12, 0.50), (0.25, 0.25)], 'arm': 0.12, 'trail': 0.08, 'tmax': 10800, 'tmin': 0.03, 'cool': 300},
    {'name': 'Le Surfeur', 'emoji': '🏄', 'col': '#ffd23f', 'fn': s_trend,
     'blurb': 'Suit les tendances des gros coins (300k-50M$) en breakout confirmé, sans poursuivre les pics.',
     'size': 0.20, 'maxpos': 2, 'sl': -0.12, 'tp': [(0.20, 0.50), (0.45, 0.25)], 'arm': 0.20, 'trail': 0.10, 'tmax': 14400, 'tmin': 0.03, 'cool': 300},
]
CFG = {b['name']: b for b in BOTS_CFG}

# ---------------------------------------------------------------- paper execution model
FEE = {'pump-fun': 0.0125, 'pumpswap': 0.0100}   # frais de swap (protocole + créateur / LP)
NET_FEE_SOL = 0.00025                            # frais réseau + priorité par transaction
LAT_SLIP = {'pump-fun': 0.010, 'pumpswap': 0.005} # glissement dû à la latence
def slip(t, size_sol):
    liq = t['liq_sol'] or (t['liq'] / 2 / FX['sol_usd'] if FX['sol_usd'] else 0) or 30.0
    if t['dex'] == 'pump-fun': liq = max(liq, 30.0)  # réserves virtuelles de la courbe
    return LAT_SLIP.get(t['dex'], 0.01) + size_sol / max(liq, 1.0)

def eur_to_sol(e): return e / FX['sol_eur']

STATE = {'version': 1, 'start': None, 'bots': {}, 'trades': [], 'seq': 0}
def new_bot(n):
    return {'name': n, 'cash': START_EUR, 'start_eur': START_EUR, 'pos': [], 'realized': 0.0, 'fees': 0.0, 'trades': 0, 'wins': 0, 'losses': 0,
            'last_entry': 0, 'bans': {}, 'last_reason': '', 'best': None, 'worst': None}
def held_mints():
    s = set()
    for b in STATE['bots'].values():
        for p in b['pos']: s.add(p['mint'])
    return s

def pos_value_eur(p):
    t = TOK.get(p['mint'])
    px = t['px_sol'] if t and t['px_sol'] else p['last_px']
    return p['qty'] * px * FX['sol_eur'], px

def bot_equity(b):
    return b['cash'] + sum(pos_value_eur(p)[0] * (1 - FEE.get(p['dex'], 0.01)) for p in b['pos'])

def record_trade(bot, side, t, p, eur, pnl=None, reason=''):
    STATE['seq'] += 1
    r = {'id': STATE['seq'], 'ts': ts(), 'epoch': round(now(), 1), 'bot': bot, 'side': side, 'sym': t['sym'], 'mint': t['mint'], 'dex': t['dex'],
         'px_sol': p, 'eur': round(eur, 4), 'pnl_eur': None if pnl is None else round(pnl, 4), 'reason': reason}
    STATE['trades'].append(r); del STATE['trades'][:-400]
    try:
        with open(P('trades.jsonl'), 'a') as f: f.write(json.dumps(r, ensure_ascii=False) + '\n')
    except Exception: pass

def buy(b, c, t, score, why):
    size_eur = round(min(b['cash'], max(1.0, bot_equity(b) * c['size'])), 4)
    if size_eur < 1.0 or b['cash'] < 1.0: return False
    size_sol = eur_to_sol(size_eur)
    sp = slip(t, size_sol); px = t['px_sol'] * (1 + sp)
    fee_sol = size_sol * FEE[t['dex']] + NET_FEE_SOL
    qty = (size_sol - fee_sol) / px
    if qty <= 0: return False
    b['cash'] -= size_eur; b['fees'] += fee_sol * FX['sol_eur']; b['last_entry'] = now()
    p = {'mint': t['mint'], 'sym': t['sym'], 'dex': t['dex'], 'qty': qty, 'qty0': qty, 'entry_px': t['px_sol'], 'fill_px': px, 'cost_eur': size_eur,
         'opened': now(), 'peak': t['px_sol'], 'tp_done': [], 'last_px': t['px_sol'], 'realized': 0.0, 'why': why}
    b['pos'].append(p)
    record_trade(b['name'], 'BUY', t, px, size_eur, None, why)
    log_ev('buy', f"ACHAT {t['sym']} {size_eur:.2f}€ ({why})", b['name'], mint=t['mint'], eur=round(size_eur, 2))
    return True

def sell(b, p, frac, reason):
    t = TOK.get(p['mint']) or tok(p['mint'])
    q = p['qty'] if frac >= 0.999 else min(p['qty'], p['qty0'] * frac)
    if q <= 0: return
    mid = t['px_sol'] if t['px_sol'] else p['last_px']
    sol_out_mid = q * mid
    sp = slip(t, sol_out_mid)
    sol = sol_out_mid * (1 - sp) * (1 - FEE.get(p['dex'], 0.01)) - NET_FEE_SOL
    sol = max(0.0, sol)
    eur = sol * FX['sol_eur']
    cost = p['cost_eur'] * (q / p['qty0'])
    pnl = eur - cost
    b['fees'] += (sol_out_mid * FEE.get(p['dex'], 0.01) + NET_FEE_SOL) * FX['sol_eur']
    b['cash'] += eur; p['qty'] -= q; p['realized'] += pnl; b['realized'] += pnl
    closed = p['qty'] <= p['qty0'] * 1e-6
    record_trade(b['name'], 'SELL' if closed else 'TP', t, mid, eur, pnl, reason)
    log_ev('sell', f"{'VENTE' if closed else 'VENTE PARTIELLE'} {p['sym']} {int(round(frac*100)) if not closed or frac<0.999 else 100}% → {eur:.2f}€ ({pnl:+.2f}€) · {reason}", b['name'], mint=p['mint'], pnl_eur=round(pnl, 3))
    if closed:
        b['pos'].remove(p); b['trades'] += 1
        tot = p['realized']; pct = tot / p['cost_eur'] * 100
        if tot >= 0: b['wins'] += 1
        else: b['losses'] += 1
        if b['best'] is None or pct > b['best']['pct']: b['best'] = {'sym': p['sym'], 'pct': round(pct, 1)}
        if b['worst'] is None or pct < b['worst']['pct']: b['worst'] = {'sym': p['sym'], 'pct': round(pct, 1)}
        b['bans'][p['mint']] = now() + (24 * 3600 if 'stop-loss' in reason else 2 * 3600)

def manage(b, c):
    for p in list(b['pos']):
        t = TOK.get(p['mint'])
        if not t or not t['px_sol']: continue
        px = t['px_sol']; p['last_px'] = px
        if now() - t['px_t'] > 90: continue          # prix trop vieux : on attend une donnée fraîche
        p['peak'] = max(p['peak'], px)
        g = px / p['entry_px'] - 1
        sl = c['sl'] if not p['tp_done'] else max(c['sl'], -0.02)   # après le 1er TP : stop au prix d'entrée
        if g <= sl:
            sell(b, p, 1.0, ('stop-loss %.0f%%' % (c['sl'] * 100)) if not p['tp_done'] else 'stop break-even'); continue
        for i, (lvl, fr) in enumerate(c['tp']):
            if i not in p['tp_done'] and g >= lvl:
                p['tp_done'].append(i); sell(b, p, fr, 'take-profit +%d%%' % (lvl * 100))
        if p not in b['pos']: continue
        pk = p['peak'] / p['entry_px'] - 1
        if pk >= c['arm'] and px <= p['peak'] * (1 - c['trail']):
            sell(b, p, 1.0, 'stop suiveur -%d%% depuis le sommet (+%.0f%%)' % (c['trail'] * 100, pk * 100)); continue
        if now() - p['opened'] > c['tmax'] and g < c['tmin']:
            sell(b, p, 1.0, 'temps max %d min' % (c['tmax'] / 60)); continue

def scan(b, c):
    if night_pause(): b['last_reason'] = 'pause nuit (01h-08h)'; return
    if len(b['pos']) >= c['maxpos']: b['last_reason'] = 'positions max'; return
    if now() - b['last_entry'] < c['cool']: b['last_reason'] = 'cooldown'; return
    if b['cash'] < 1.0: b['last_reason'] = 'cash < 1€'; return
    if FX['sol_eur'] <= 0: return
    best = None
    held = {p['mint'] for p in b['pos']}
    for t in list(TOK.values()):
        if t['mint'] in held or b['bans'].get(t['mint'], 0) > now(): continue
        if not fresh(t) or not t['g_t'] or now() - t['g_t'] > 600: continue
        sc, why = c['fn'](t)
        if sc <= 0: continue
        rf = red_flags(t)
        if rf: continue
        if best is None or sc > best[0]: best = (sc, t, why)
    STATS['evals'] += 1
    if best: buy(b, c, best[1], best[0], best[2])
    else: b['last_reason'] = 'scan…'

# ---------------------------------------------------------------- persistence / snapshot
HIST = {}   # bot -> list[[t, eq]]
def save_state():
    tmp = P('state.json.tmp')
    with open(tmp, 'w') as f: json.dump({'state': STATE, 'hist': HIST}, f)
    os.replace(tmp, P('state.json'))
def load_state():
    try:
        d = json.load(open(P('state.json')))
        STATE.update(d['state']); HIST.update(d.get('hist', {}))
        for b in STATE['bots'].values():
            for p in b['pos']:
                t = tok(p['mint']); t['sym'] = p['sym']; t['dex'] = p['dex']; t['px_sol'] = p['last_px']
        return True
    except FileNotFoundError: return False

def add_hist(n, eq):
    h = HIST.setdefault(n, [])
    t = round(now())
    if h and t - h[-1][0] < 30: h[-1] = [h[-1][0], round(eq, 4)]
    else: h.append([t, round(eq, 4)])
    if len(h) > 6000:   # au-delà : on compresse les vieux points (1 sur 2)
        HIST[n] = h[:-3000:2] + h[-3000:]

def snapshot():
    bots = []
    tot = 0.0
    for c in BOTS_CFG:
        b = STATE['bots'][c['name']]; eq = bot_equity(b); tot += eq
        pos = []
        for p in b['pos']:
            v, px = pos_value_eur(p)
            t = TOK.get(p['mint']) or {}
            pos.append({'sym': p['sym'], 'mint': p['mint'], 'dex': p['dex'], 'cost_eur': round(p['cost_eur'] * p['qty'] / p['qty0'], 3), 'value_eur': round(v, 3),
                        'gain_pct': round((px / p['entry_px'] - 1) * 100, 2), 'peak_pct': round((p['peak'] / p['entry_px'] - 1) * 100, 1),
                        'left_pct': round(p['qty'] / p['qty0'] * 100), 'tp_done': len(p['tp_done']), 'age_s': round(now() - p['opened']),
                        'mcap': round(t.get('mcap', 0)), 'px_age_s': round(now() - t.get('px_t', 0)) if t.get('px_t') else None, 'why': p['why']})
        n = b['wins'] + b['losses']
        bots.append({'name': c['name'], 'emoji': c['emoji'], 'col': c['col'], 'blurb': c['blurb'], 'equity_eur': round(eq, 4), 'cash_eur': round(b['cash'], 4),
                     'start_eur': b['start_eur'], 'pnl_eur': round(eq - b['start_eur'], 4), 'pnl_pct': round((eq / b['start_eur'] - 1) * 100, 2),
                     'realized_eur': round(b['realized'], 4), 'fees_eur': round(b['fees'], 4), 'trades': b['trades'], 'wins': b['wins'], 'losses': b['losses'],
                     'win_rate': round(b['wins'] / n * 100, 1) if n else None, 'positions': pos, 'status': b['last_reason'], 'best': b['best'], 'worst': b['worst'],
                     'rules': {'size_pct': round(c['size'] * 100), 'maxpos': c['maxpos'], 'sl_pct': round(c['sl'] * 100), 'tp': [[round(l * 100), round(f * 100)] for l, f in c['tp']],
                               'trail_arm_pct': round(c['arm'] * 100), 'trail_pct': round(c['trail'] * 100), 'tmax_min': c['tmax'] / 60, 'cooldown_s': c['cool']}})
    st = STATE['start']
    snap = {'mode': 'SIMULATION', 'updated': ts(), 'epoch': round(now(), 1), 'start': st, 'start_ts': ts(st) if st else None,
            'end_test_ts': ts(st + 7 * 86400) if st else None, 'total_eur': round(tot, 4), 'start_total_eur': START_EUR * len(BOTS_CFG),
            'night_pause': night_pause(), 'night_rule': 'Pause nuit : aucune nouvelle entrée de 01h00 à 08h00 (heure de Paris), positions ouvertes toujours gérées',
            'sol_eur': FX['sol_eur'], 'sources': dict(SRC), 'stats': dict(STATS), 'bots': bots, 'trades': STATE['trades'][-80:][::-1], 'events': list(EVENTS)[-60:][::-1]}
    return snap

def write_json(name, obj):
    tmp = P(name + '.tmp')
    with open(tmp, 'w') as f: json.dump(obj, f, ensure_ascii=False, separators=(',', ':'))
    os.replace(tmp, P(name))

def hist_export():
    out = {}
    for n, h in HIST.items():
        # dernières 2h à 30 s + le reste à ~5 min
        cut = now() - 7200; recent = [x for x in h if x[0] >= cut]; old = [x for x in h if x[0] < cut]
        step = max(1, len(old) // 1500) if old else 1
        out[n] = old[::step] + recent
    return out

# ---------------------------------------------------------------- main
def main():
    if not load_state():
        STATE['start'] = round(now()); STATE['bots'] = {c['name']: new_bot(c['name']) for c in BOTS_CFG}
        log_ev('start', 'Départ de la simulation : 5 bots × 10 € fictifs = 50 €. Test 1 semaine.')
    for c in BOTS_CFG: STATE['bots'].setdefault(c['name'], new_bot(c['name']))
    log_ev('resume', 'Moteur démarré (SIMULATION, aucune transaction réelle)')
    for fn in (fx_loop, gecko_loop, dex_loop): threading.Thread(target=fn, daemon=True).start()
    last_save = last_hist = last_hexp = 0; was_night = None
    while True:
        try:
            with LOCK:
                nightp = night_pause()
                if nightp != was_night and was_night is not None:
                    log_ev('night', '🌙 Pause nuit : plus de nouvelles entrées jusqu’à 08h00' if nightp else '☀️ Fin de la pause nuit : les bots peuvent de nouveau entrer')
                was_night = nightp
                if FX['sol_eur'] > 0:
                    for c in BOTS_CFG:
                        b = STATE['bots'][c['name']]
                        manage(b, c); scan(b, c)
                    write_json('snapshot.json', snapshot())
                    if now() - last_hist >= 30:
                        last_hist = now()
                        for c in BOTS_CFG: add_hist(c['name'], bot_equity(STATE['bots'][c['name']]))
                        add_hist('TOTAL', sum(bot_equity(STATE['bots'][c['name']]) for c in BOTS_CFG))
                    if now() - last_hexp >= 30:
                        last_hexp = now(); write_json('history.json', hist_export())
                    if now() - last_save >= 5:
                        last_save = now(); save_state()
        except Exception:
            traceback.print_exc()
        time.sleep(1.0)

if __name__ == '__main__':
    main()
