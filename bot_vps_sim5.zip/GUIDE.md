# 🤖 Grok Bot · 5 bots Pump.fun en SIMULATION sur ton VPS (Hetzner Ubuntu)

**100 % fictif** : 5 bots × 10 € fictifs = 50 €. Aucune clé privée, aucun wallet, aucune transaction.
Les prix sont réels (GeckoTerminal, DexScreener, Binance), les frais et le slippage sont simulés.
Pause nuit : **aucune nouvelle entrée de 01h00 à 08h00 (heure de Paris)**. Les positions ouvertes restent gérées (stop-loss, take-profit, stop suiveur).

Dashboard : **https://elalonsoo.github.io/kimchi/** (il trouve tout seul l'adresse du VPS).

---

## 1. Envoyer le zip sur le VPS
Depuis ton PC (remplace `IP_DU_VPS`) :
```bash
scp bot_vps_sim5.zip root@IP_DU_VPS:/root/
```
(Sur téléphone : tu peux aussi utiliser l'appli Termius → SFTP → envoyer le fichier dans `/root/`.)

## 2. Se connecter et installer
```bash
ssh root@IP_DU_VPS
cd /root && apt-get install -y unzip && unzip -o bot_vps_sim5.zip -d sim5 && cd sim5
bash install.sh
```
C'est tout : le service **pumpbot-sim** démarre et redémarre tout seul (même après un reboot du VPS).
Il désactive aussi l'ancien service `pumpbot` (bot réel gar0u) s'il existe.

> Repartir de zéro (nouvelle course 5 × 10 €) : `bash install.sh --fresh`
> Sans `--fresh`, la course continue là où elle en était (fichier `data/state.json` inclus dans le zip).

## 3. ⚠️ Arrêter la version du box Grok Bot
Une seule instance doit tourner (sinon les deux se disputent le dashboard).
Demande à Grok Bot : « arrête la simulation sur le box » (il lance `bash /workspace/simbots/stop_all.sh`).

## 4. Vérifier
```bash
systemctl status pumpbot-sim          # doit afficher "active (running)"
tail -f /root/sim5/data/logs/bots.log # achats / ventes en direct (Ctrl+C pour quitter)
cat /root/sim5/data/public_url.txt    # adresse publique de l'API
curl -s localhost:8800/health         # {"ok":true}
```

## 5. Commandes utiles
```bash
systemctl restart pumpbot-sim   # relancer
systemctl stop pumpbot-sim      # arrêter
systemctl start pumpbot-sim     # démarrer
journalctl -u pumpbot-sim -f    # journal systemd
```

## Les 5 bots (10 € fictifs chacun)
| Bot | Stratégie | Stop-loss | Take-profit | Stop suiveur |
|---|---|---|---|---|
| 💎 Le Sélectionneur | meilleurs coins : vrais acheteurs, volume, liquidité, tendance saine | -14 % | +25 % → vend 50 %, +60 % → 25 % | -12 % dès +25 % |
| 🎓 Le Diplômé | coins qui viennent de migrer sur PumpSwap (3-90 min) | -16 % | +35 % → 50 %, +80 % → 25 % | -15 % dès +35 % |
| 🎯 Le Sniper | coins très jeunes (2-15 min), filtres stricts, petites mises (8 %) | -20 % | +50 % → 50 %, +120 % → 30 % | -20 % dès +50 % |
| 🪝 Le Chasseur de Creux | creux de -12 à -45 % sur 1h de coins établis en tendance, au rebond | -10 % | +12 % → 50 %, +25 % → 25 % | -8 % dès +12 % |
| 🏄 Le Surfeur | breakouts de gros coins (300k-50M $) | -12 % | +20 % → 50 %, +45 % → 25 % | -10 % dès +20 % |

Pour tous : après le 1er take-profit, le stop remonte au prix d'entrée ; durée max par trade ; pause entre deux achats ; un coin stoppé est banni 24 h.

## Fichiers
- `bots_sim.py` : les 5 bots (simulation) · `server.py` : API lecture seule (port 8800)
- `tunnel.py` : tunnel public (cloudflared sur le VPS) · `publish_url.sh` : publie l'URL pour le dashboard (ntfy)
- `run_all.sh` : lance tout avec redémarrage auto · `stop_all.sh` : arrête tout
- `data/` : état de la course, historique, trades, logs
