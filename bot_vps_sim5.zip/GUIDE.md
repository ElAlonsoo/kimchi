# 🤖 Grok Bot · 4 bots Pump.fun en SIMULATION sur ton VPS (Hetzner Ubuntu)

**100 % fictif** : 4 bots × 60 € fictifs au départ (Le Sniper ne trade plus depuis le 15/11 : 0,56 € archivé, rien redistribué). Aucune clé privée, aucun wallet, aucune transaction.
Les prix sont réels (GeckoTerminal, DexScreener, Binance), les frais et le slippage sont simulés.
Pause nuit : **aucune nouvelle entrée de 01h00 à 08h00 (heure de Paris)**. Les positions ouvertes restent gérées (stop-loss, take-profit, stop suiveur).

Dashboard : **https://elalonsoo.github.io/kimchi/** (il trouve tout seul l'adresse du VPS).

---

## 1. Envoyer le zip sur le VPS
Depuis ton PC (remplace `IP_DU_VPS`) :
```bash
scp bot_vps_sim5.zip root@IP_DU_VPS:/root/
```
(Sur téléphone : tu peux aussi utiliser l'appli Termius → SFTP → envoyer le fichier dans `/root/`.)

## 2. Se connecter et installer
```bash
ssh root@IP_DU_VPS
cd /root && apt-get install -y unzip && unzip -o bot_vps_sim5.zip -d sim5 && cd sim5
bash install.sh
```
C'est tout : le service **pumpbot-sim** démarre et redémarre tout seul (même après un reboot du VPS).
Il désactive aussi l'ancien service `pumpbot` (bot réel gar0u) s'il existe.

> Repartir de zéro (nouvelle course 4 × 60 €) : `bash install.sh --fresh`
> Sans `--fresh`, la course continue là où elle en était : `data/` sur le VPS n'est jamais écrasé.

## 3. ⚠️ Arrêter la version du box Grok Bot
Une seule instance doit tourner (sinon les deux se disputent le dashboard).
Demande à Grok Bot : « arrête la simulation sur le box » (il lance `bash /workspace/simbots/stop_all.sh`).

## 4. Vérifier
```bash
systemctl status pumpbot-sim          # doit afficher "active (running)"
tail -f /root/sim5/data/logs/bots.log # achats / ventes en direct (Ctrl+C pour quitter)
cat /root/sim5/data/public_url.txt    # adresse publique de l'API
curl -s localhost:8800/health         # {"ok":true}
```

## 5. Commandes utiles
```bash
systemctl restart pumpbot-sim   # relancer
systemctl stop pumpbot-sim      # arrêter
systemctl start pumpbot-sim     # démarrer
journalctl -u pumpbot-sim -f    # journal systemd
```

## Les 4 bots (60 € fictifs chacun) · réglages v3 du 15/11/2026
Le Sniper ne trade plus : son solde (0,56 €) est archivé tel quel, rien n'est redistribué. Aucun solde, historique ou position ouverte n'est modifié par la mise à jour : les positions déjà ouvertes gardent leurs anciennes règles, les nouvelles suivent les règles ci-dessous.

Take-profit : chaque palier vend une seule fois un % de ce qui RESTE. Aucun take-profit sous +50 %.

| Bot | Stop-loss | Take-profit (du reste) | Stop suiveur (recul max depuis le sommet) | Break-even |
|---|---|---|---|---|
| 💎 Le Sélectionneur | -15 % | +50→20 %, +100→30 %, +200→45 %, +300→60 %, +500→90 % | -28 % dès +40 %, -30 % dès +100 %, -25 % dès +200 %, -22 % dès +300 %, -18 % dès +500 % | entrée +5 % |
| 🎓 Le Diplômé | -20 % | +50→15 %, +100→25 %, +200→40 %, +300→55 %, +500→85 % | -30 % dès +40 %, -32 % dès +100 %, -28 % dès +200 %, -24 % dès +300 %, -20 % dès +500 % | entrée +5 % |
| 🪝 Le Chasseur de Creux | -20 % | +50→25 %, +100→35 %, +200→50 %, +300→60 %, +500→90 % | -22 % dès +30 %, -25 % dès +60 %, -25 % dès +100 %, -22 % dès +200 %, -20 % dès +300 %, -16 % dès +500 % | entrée +3 % |
| 🏄 Le Surfeur | -14 % | +50→20 %, +100→30 %, +200→45 %, +300→60 %, +500→90 % | -28 % dès +40 %, -30 % dès +100 %, -25 % dès +200 %, -22 % dès +300 %, -18 % dès +500 % | entrée +5 % |

Break-even : dès le 1er take-profit (ou dès que le stop suiveur est armé), le stop ne redescend jamais sous l'entrée + 3/5 % (frais couverts).
Anti-arnaque (nouvelles entrées) : refus des coins à faux volume (plus de 4 acheteurs par vendeur sur 1h), des pools avec moins de 20 SOL ou une liquidité incohérente ; Le Diplômé ne prend que les vrais coins pump.fun.

## Fichiers
- `bots_sim.py` : les 4 bots (simulation) · `server.py` : API lecture seule (port 8800 : /snapshot, /history, /trades)
- `tunnel.py` : tunnel public (cloudflared sur le VPS) · `publish_url.sh` : publie l'URL pour le dashboard (ntfy)
- `run_all.sh` : lance tout avec redémarrage auto · `stop_all.sh` : arrête tout
- `data/` : état de la course, historique, trades, logs

---

## Mise à jour (sans perdre les données)

Le zip **ne contient plus** le dossier `data/` : tes trades et soldes restent sur le VPS.

Après la première mise à jour ci-dessous, un timer systemd (`pumpbot-sim-update`) vérifie GitHub toutes les 10 minutes et applique le nouveau zip tout seul, **sans toucher à `data/` ni à `ntfy_topic.txt`**.

### Console web Hetzner (colle une ligne à la fois)

La console casse les caractères `&`, `_`, `*` et `>`. Ces deux lignes n'en ont aucun :

```bash
wget -O u.sh https://github.com/ElAlonsoo/kimchi/raw/main/up.sh
bash u.sh
```

Cela installe aussi le timer : tu n'as plus besoin de retourner sur le VPS pour les prochaines mises à jour.
