#!/bin/bash
# Lance tout (bots SIMULATION + API + tunnel + publication ntfy) avec redémarrage automatique.
# Utilisé par systemd (service pumpbot-sim) ou à la main : bash run_all.sh
HERE="$(cd "$(dirname "$0")" && pwd)"; cd "$HERE"
export PUMPBOTS_LIVE=0
export SIM_DATA="${SIM_DATA:-$HERE/data}"; mkdir -p "$SIM_DATA/logs"; L="$SIM_DATA/logs"
PY="$HERE/venv/bin/python"; [ -x "$PY" ] || PY=python3
loop(){ name=$1; shift; while true; do [ -f "$HERE/STOP" ] && exit 0; "$@" >> "$L/$name.log" 2>&1; echo "$(date '+%F %T') $name s'est arrêté (code $?), relance dans 5 s" >> "$L/supervisor.log"; sleep 5; done; }
trim(){ while true; do for f in "$L"/*.log; do [ $(stat -c%s "$f") -gt 20000000 ] && tail -n 20000 "$f" > "$f.t" && mv "$f.t" "$f"; done; sleep 600; done; }
rm -f "$HERE/STOP"
loop bots "$PY" -u bots_sim.py &
loop server "$PY" -u server.py &
loop tunnel "$PY" -u tunnel.py &
loop publish bash publish_url.sh &
trim &
# surveillance du tunnel : si l'URL publique ne répond plus 3 fois de suite, on relance le tunnel
watch(){ f=0; sleep 60; while true; do u=$(tr -d '[:space:]' < "$SIM_DATA/public_url.txt" 2>/dev/null)
  if [ -n "$u" ]; then c=$(curl -s -o /dev/null -w "%{http_code}" -m 12 -H "X-Pinggy-No-Screen: 1" "$u/health"); if [ "$c" = "200" ]; then f=0; else f=$((f+1)); fi
    if [ $f -ge 3 ]; then echo "$(date '+%F %T') tunnel KO ($c) -> relance" >> "$L/supervisor.log"; pkill -f -- "-u tunnel\.py"; pkill -f "cloudflared tunnel --no-autoupdate --url http://localhost"; f=0; sleep 30; fi; fi
  sleep 30; done; }
watch &
echo "$(date '+%F %T') run_all démarré (pid $$)" >> "$L/supervisor.log"
trap 'touch "$HERE/STOP"; pkill -P $$; sleep 1; pkill -f "bots_sim\.py|-u server\.py|-u tunnel\.py|publish_url\.sh|cloudflared tunnel --no-autoupdate --url http://localhost" ; rm -f "$HERE/STOP"; exit 0' TERM INT
wait
