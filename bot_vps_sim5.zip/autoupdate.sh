#!/bin/bash
# Mise a jour auto du bot de SIMULATION depuis GitHub.
# Ne touche jamais a data/ (etat, trades, logs) ni a ntfy_topic.txt.
# Aucune cle, aucune transaction reelle.
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
URL="https://raw.githubusercontent.com/ElAlonsoo/kimchi/main/bot_vps_sim5.zip"
SHA_FILE="$DIR/data/.zipsha"
TMPZIP="/tmp/bot-vps-sim5-new.zip"
UNPACK="/tmp/bot-vps-sim5-unpack"

mkdir -p "$DIR/data"

if ! curl -fsSL --retry 3 --retry-delay 2 -o "$TMPZIP" "$URL"; then
  echo "telechargement impossible, on reporte"
  exit 0
fi
if [ ! -s "$TMPZIP" ]; then
  echo "zip vide, on reporte"
  exit 0
fi
if ! unzip -t "$TMPZIP" >/dev/null 2>&1; then
  echo "zip invalide, on reporte"
  rm -f "$TMPZIP"
  exit 0
fi

NEW=$(sha256sum "$TMPZIP" | awk '{print $1}')
OLD=""
if [ -f "$SHA_FILE" ]; then
  OLD=$(tr -d ' \n' < "$SHA_FILE")
fi
if [ -n "$OLD" ] && [ "$NEW" = "$OLD" ]; then
  rm -f "$TMPZIP"
  exit 0
fi

rm -rf "$UNPACK"
mkdir -p "$UNPACK"
unzip -o "$TMPZIP" -d "$UNPACK" >/dev/null
SRC="$UNPACK"
if [ ! -f "$SRC/bots_sim.py" ] && [ -f "$SRC/simbots/bots_sim.py" ]; then
  SRC="$SRC/simbots"
fi
if [ ! -f "$SRC/bots_sim.py" ]; then
  echo "bots_sim.py absent du zip, on annule"
  rm -rf "$UNPACK" "$TMPZIP"
  exit 0
fi
rm -rf "$SRC/data" "$SRC/venv"
rm -f "$SRC/ntfy_topic.txt"

for f in "$SRC"/*; do
  [ -e "$f" ] || continue
  base=$(basename "$f")
  case "$base" in
    data|ntfy_topic.txt|venv) continue ;;
  esac
  cp -a "$f" "$DIR/"
done

chmod +x "$DIR"/*.sh 2>/dev/null || true
echo "$NEW" > "$SHA_FILE"
rm -rf "$UNPACK" "$TMPZIP"

if command -v systemctl >/dev/null 2>&1; then
  if [ "$(id -u)" -eq 0 ]; then
    systemctl restart pumpbot-sim || true
  else
    sudo systemctl restart pumpbot-sim || true
  fi
fi
echo "mise a jour appliquee $NEW"
