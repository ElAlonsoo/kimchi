#!/bin/bash
# Installation sur un VPS Ubuntu (Hetzner) : bash install.sh
# - SIMULATION uniquement : aucune clé privée, aucune transaction.
# - Crée le venv Python, installe cloudflared (tunnel public), et le service systemd "pumpbot-sim" (redémarrage auto).
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"; cd "$DIR"
SUDO=""; [ "$(id -u)" -ne 0 ] && SUDO="sudo"
RUNUSER="${SUDO_USER:-$(id -un)}"
echo "==> Paquets système"
$SUDO apt-get update -y >/dev/null
$SUDO apt-get install -y python3 python3-venv python3-pip curl unzip tzdata >/dev/null
$SUDO timedatectl set-timezone Europe/Paris 2>/dev/null || true
echo "==> cloudflared (tunnel public gratuit)"
if ! command -v cloudflared >/dev/null; then
  ARCH=$(dpkg --print-architecture)
  curl -fsSL -o /tmp/cloudflared.deb "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-${ARCH}.deb"
  $SUDO dpkg -i /tmp/cloudflared.deb >/dev/null && rm -f /tmp/cloudflared.deb
fi
echo "==> Environnement Python"
[ -d venv ] || python3 -m venv venv
./venv/bin/pip install -q --upgrade pip
./venv/bin/pip install -q -r requirements.txt
mkdir -p data/logs; chmod +x *.sh
$SUDO chown -R "$RUNUSER" "$DIR"
if [ "$1" = "--fresh" ]; then echo "==> Remise à zéro (nouvelle course 5 x 10 EUR)"; rm -f data/state.json data/history.json data/snapshot.json data/trades.jsonl data/events.jsonl; fi
echo "==> Ancien bot réel (copy-trade) : on s'assure qu'il reste arrêté"
if systemctl list-unit-files 2>/dev/null | grep -q '^pumpbot\.service'; then $SUDO systemctl disable --now pumpbot || true; fi
echo "==> Service systemd pumpbot-sim"
$SUDO tee /etc/systemd/system/pumpbot-sim.service >/dev/null <<UNIT
[Unit]
Description=Grok Bot - 5 bots Pump.fun en SIMULATION (10 EUR fictifs chacun) + API + tunnel
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=$RUNUSER
WorkingDirectory=$DIR
Environment=PUMPBOTS_LIVE=0
Environment=TUNNEL=cloudflared
ExecStart=/bin/bash $DIR/run_all.sh
Restart=always
RestartSec=5
KillMode=control-group

[Install]
WantedBy=multi-user.target
UNIT
$SUDO systemctl daemon-reload
$SUDO systemctl enable --now pumpbot-sim
echo "==> Attente de l'URL publique…"
for i in $(seq 40); do [ -s data/public_url.txt ] && break; sleep 2; done
echo
echo "✅ Installé. Statut : $($SUDO systemctl is-active pumpbot-sim)"
echo "   URL API : $(cat data/public_url.txt 2>/dev/null || echo 'pas encore, réessaie dans 1 min : cat data/public_url.txt')"
echo "   Dashboard : https://elalonsoo.github.io/kimchi/  (trouve l'URL tout seul en ~10 s)"
echo "   Logs : tail -f $DIR/data/logs/bots.log"
