#!/bin/bash
# Arrête proprement tout (bots + API + tunnel + ntfy). Les données (data/) sont conservées.
HERE="$(cd "$(dirname "$0")" && pwd)"
if systemctl is-active --quiet pumpbot-sim 2>/dev/null; then sudo systemctl stop pumpbot-sim; fi
touch "$HERE/STOP"
pkill -f "run_all.sh" ; pkill -f "bots_sim.py" ; pkill -f "simbots.*server.py|$HERE/server.py|-u server.py" ; pkill -f "tunnel.py" ; pkill -f "publish_url.sh"
pkill -f "cloudflared tunnel --no-autoupdate --url http://localhost" 2>/dev/null
sleep 1; rm -f "$HERE/STOP"; echo "Tout est arrêté."
